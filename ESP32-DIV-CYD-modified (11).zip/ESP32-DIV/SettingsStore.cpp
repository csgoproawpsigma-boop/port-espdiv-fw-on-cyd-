#include <ArduinoJson.h>
#include <SD.h>
#include "SettingsStore.h"
#include "utils.h"


static AppSettings g_settings;
AppSettings& settings() { return g_settings; }

// Each entry: { name, primary-color, secondary-color }
// primary  → used for all UI accent highlights (badge, switch-on, icon tint)
// secondary → shown as the right half of the accent swatch in Settings for a
//             duo-tone / gradient preview; purely decorative, not used elsewhere
static const AccentOption kAccentPresets[] = {
  // ── originals ─────────────────────────────────────────────────────────────
  {"Orange",  0xFBE4, 0xF800},   // orange  → red
  {"Green",   0xB721, 0x07E0},   // mid-grn → bright green
  {"Red",     0xF800, 0xF81F},   // red     → magenta
  {"Cyan",    0x07FF, 0x001F},   // cyan    → blue
  {"Purple",  0xF81F, 0x601F},   // magenta → deep violet
  {"Yellow",  0xFFE0, 0xFBE4},   // yellow  → orange
  {"White",   0xFFFF, 0xBDD7},   // white   → silver/grey
  // ── new gradient-flavoured additions ──────────────────────────────────────
  {"Ocean",   0x0497, 0x07FF},   // deep blue → cyan   (ocean depth)
  {"Mint",    0x47EA, 0xB7FF},   // mint green → sky blue
  {"Gold",    0xF7A0, 0xFFE0},   // warm gold → yellow
  {"Rose",    0xF8B2, 0xF81F},   // rose pink → magenta
  {"Neon",    0xC7FE, 0x07E0},   // neon lime → bright green
};

uint8_t accentPresetClamp(uint8_t preset) {
  if (preset >= ACCENT_PRESET_COUNT) return 0;
  return preset;
}

uint16_t accentColor565(uint8_t preset) {
  return kAccentPresets[accentPresetClamp(preset)].color565;
}

uint16_t accentColor565_b(uint8_t preset) {
  return kAccentPresets[accentPresetClamp(preset)].color565_b;
}

const char* accentPresetName(uint8_t preset) {
  return kAccentPresets[accentPresetClamp(preset)].name;
}

const char* settingsBoardProfileId() {
  return TOUCH_PROFILE_ID;
}

void settingsApplyBoardTouchDefaults() {
  auto& s = g_settings;
  s.touchXMin = TOUCH_X_MIN;
  s.touchXMax = TOUCH_X_MAX;
  s.touchYMin = TOUCH_Y_MIN;
  s.touchYMax = TOUCH_Y_MAX;
}

static bool settingsTouchSavedForBoard(const StaticJsonDocument<768>& doc) {
  JsonObjectConst touch = doc["touch"];
  if (touch.isNull()) {
    return false;
  }
  if (!touch["xMin"].is<uint16_t>() || !touch["xMax"].is<uint16_t>() ||
      !touch["yMin"].is<uint16_t>() || !touch["yMax"].is<uint16_t>()) {
    return false;
  }
  const char* savedBoard = doc["board"] | "";
  if (savedBoard[0] == '\0') {
    return true;
  }
  return strcmp(savedBoard, TOUCH_PROFILE_ID) == 0;
}

static bool sd_mounted = false;
static bool mountSD() {

  if (sd_mounted) {
    if (SD.cardType() != CARD_NONE) return true;
    sd_mounted = false;
  }

  sd_mounted = isSDCardAvailable();
  return sd_mounted;
}

static bool ensureDir(const char* dirPath) {
  if (!mountSD()) return false;
  if (!SD.exists(dirPath)) {
    if (SD.mkdir(dirPath)) return true;

    if (dirPath && dirPath[0] == '/') {
      return SD.mkdir(dirPath + 1);
    }
    return false;
  }
  return true;
}

bool settingsLoad() {
  settingsApplyBoardTouchDefaults();
  sdRetryMount();
  if (!mountSD()) return false;
  if (!SD.exists(SETTINGS_PATH)) return true;

  File f = SD.open(SETTINGS_PATH, FILE_READ);
  if (!f) return false;

  StaticJsonDocument<768> doc;
  DeserializationError err = deserializeJson(doc, f);
  f.close();
  if (err) return false;

  auto& s = g_settings;
  s.brightness      = doc["brightness"]      | s.brightness;
  s.theme           = (Theme)(uint8_t)(doc["theme"] | (uint8_t)s.theme);
  s.accentColor     = accentPresetClamp(doc["accentColor"] | s.accentColor);
  s.neopixelEnabled = doc["neopixelEnabled"] | s.neopixelEnabled;

  s.autoWifiScan    = doc["autoWifiScan"]    | s.autoWifiScan;
  s.autoBleScan     = doc["autoBleScan"]     | s.autoBleScan;

  s.moduleNrf24Enabled  = doc["moduleNrf24Enabled"]  | s.moduleNrf24Enabled;
  s.moduleCc1101Enabled = doc["moduleCc1101Enabled"] | s.moduleCc1101Enabled;
  s.moduleIrEnabled     = doc["moduleIrEnabled"]     | s.moduleIrEnabled;
  s.moduleRfidEnabled   = doc["moduleRfidEnabled"]   | s.moduleRfidEnabled;
  s.moduleGpsEnabled    = doc["moduleGpsEnabled"]    | s.moduleGpsEnabled;
  s.catEasterEggEnabled = doc["catEasterEggEnabled"] | s.catEasterEggEnabled;
  s.tftInvertColors     = doc["tftInvertColors"]     | s.tftInvertColors;
  s.extrasEnabled       = doc["extrasEnabled"]       | s.extrasEnabled;

  if (s.autoWifiScan != s.autoBleScan) {
    bool en = (s.autoWifiScan || s.autoBleScan);
    s.autoWifiScan = en;
    s.autoBleScan  = en;
  }

  if (settingsTouchSavedForBoard(doc)) {
    JsonObjectConst touch = doc["touch"];
    s.touchXMin = touch["xMin"] | s.touchXMin;
    s.touchXMax = touch["xMax"] | s.touchXMax;
    s.touchYMin = touch["yMin"] | s.touchYMin;
    s.touchYMax = touch["yMax"] | s.touchYMax;
  } else {
    settingsApplyBoardTouchDefaults();
  }

  return true;
}

bool settingsSave() {
  sdRetryMount();

  if (!ensureDir("/config")) {
    sd_mounted = false;
    if (!ensureDir("/config")) return false;
  }

  File f = SD.open(SETTINGS_PATH, FILE_WRITE);
  if (!f) {
    sd_mounted = false;
    if (!mountSD()) return false;
    f = SD.open(SETTINGS_PATH, FILE_WRITE);
    if (!f) return false;
  }

  auto& s = g_settings;
  StaticJsonDocument<768> doc;
  doc["board"]           = TOUCH_PROFILE_ID;
  doc["brightness"]      = s.brightness;
  doc["theme"]           = (uint8_t)s.theme;
  doc["accentColor"]     = s.accentColor;
  doc["neopixelEnabled"] = s.neopixelEnabled;

  doc["autoWifiScan"]    = s.autoWifiScan;
  doc["autoBleScan"]     = s.autoBleScan;

  doc["moduleNrf24Enabled"]  = s.moduleNrf24Enabled;
  doc["moduleCc1101Enabled"] = s.moduleCc1101Enabled;
  doc["moduleIrEnabled"]     = s.moduleIrEnabled;
  doc["moduleRfidEnabled"]   = s.moduleRfidEnabled;
  doc["moduleGpsEnabled"]    = s.moduleGpsEnabled;
  doc["catEasterEggEnabled"] = s.catEasterEggEnabled;
  doc["tftInvertColors"]     = s.tftInvertColors;
  doc["extrasEnabled"]       = s.extrasEnabled;

  JsonObject t = doc.createNestedObject("touch");
  t["xMin"] = s.touchXMin;
  t["xMax"] = s.touchXMax;
  t["yMin"] = s.touchYMin;
  t["yMax"] = s.touchYMax;

  bool ok = serializeJson(doc, f) > 0;
  f.close();
  return ok;
}
