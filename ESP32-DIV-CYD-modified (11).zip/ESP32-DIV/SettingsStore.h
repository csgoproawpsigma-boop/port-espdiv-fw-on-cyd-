#pragma once

#include <Arduino.h>
#include "shared.h"

#ifndef SETTINGS_PATH
#define SETTINGS_PATH "/config/settings.json"
#endif

struct AppSettings {

  uint8_t  brightness = BKL_LEVEL_MED;
  Theme    theme      = Theme::Dark;
  uint8_t  accentColor = 0;

  bool     neopixelEnabled = false;

  bool     autoWifiScan    = true;
  bool     autoBleScan     = true;

  uint16_t touchXMin = TOUCH_X_MIN;
  uint16_t touchXMax = TOUCH_X_MAX;
  uint16_t touchYMin = TOUCH_Y_MIN;
  uint16_t touchYMax = TOUCH_Y_MAX;

  // Per-module hardware presence toggles. Turn a module OFF here if you
  // haven't wired/installed that hardware (e.g. no CC1101, no NRF24) —
  // its menu entry will say "Not installed" instead of trying to init it.
  bool moduleNrf24Enabled  = true;   // 2.4GHz menu (NRF24 Scanner/ProtoKill/ESB/MouseJack)
  bool moduleCc1101Enabled = true;   // SubGHz menu (CC1101 Replay/Jammer/BruteForce/etc)
  bool moduleIrEnabled     = true;   // Other > IR Remote
  bool moduleRfidEnabled   = true;   // Other > RFID/NFC
  bool moduleGpsEnabled    = true;   // Other > GPS

  bool catEasterEggEnabled = true;   // idle screensaver cat with pentest one-liners

  // Runtime override on top of whatever TFT_INVERSION_ON/OFF was compiled
  // with (User_Setup.h). If colors look wrong on your panel, flip this —
  // no reflash needed. Default true = matches the "inverted colors" CYD
  // variant from the User_Setup cyd.h that ships with this port.
  bool tftInvertColors = true;

  // Master switch for all the non-essential "fun" additions: boot-screen
  // "ported by" banner, extra visual easter eggs, hidden mini-game.
  // Turn this off for a clean/stock-looking build.
  bool extrasEnabled = true;

};

struct AccentOption {
  const char*  name;
  uint16_t     color565;    // primary — used for all UI highlights
  uint16_t     color565_b;  // secondary — shown as the right half of the accent swatch
};

// 7 original + 5 new gradient-flavoured additions = 12 total
constexpr uint8_t ACCENT_PRESET_COUNT = 12;

AppSettings& settings();
uint8_t accentPresetClamp(uint8_t preset);
uint16_t accentColor565(uint8_t preset);
uint16_t accentColor565_b(uint8_t preset);  // secondary (swatch right-half)
const char* accentPresetName(uint8_t preset);

const char* settingsBoardProfileId();
void settingsApplyBoardTouchDefaults();
bool settingsLoad();
bool settingsSave();
