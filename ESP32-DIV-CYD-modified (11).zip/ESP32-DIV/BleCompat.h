#pragma once

#include <NimBLEDevice.h>

using BLEDevice            = NimBLEDevice;
using BLEServer            = NimBLEServer;
using BLEAdvertising       = NimBLEAdvertising;
using BLEAdvertisementData = NimBLEAdvertisementData;
using BLEScan              = NimBLEScan;
using BLEScanResults       = NimBLEScanResults;
using BLEAdvertisedDevice  = NimBLEAdvertisedDevice;
using BLEAddress           = NimBLEAddress;
using BLEUUID              = NimBLEUUID;

// NimBLE 2.x renamed NimBLEAdvertisedDeviceCallbacks → NimBLEScanCallbacks.
// onResult() now receives a *const* pointer.
// Keep the old name as an alias so existing subclasses compile unchanged —
// only the pointer constness needs updating at each call-site.
#if defined(NIMBLE_CPP_VERSION_MAJOR) && NIMBLE_CPP_VERSION_MAJOR >= 2
  using BLEAdvertisedDeviceCallbacks = NimBLEScanCallbacks;
  // setScanCallbacks is the 2.x method; we shim the old name via a macro so
  // call-sites that still write setAdvertisedDeviceCallbacks() compile as-is.
  #define setAdvertisedDeviceCallbacks setScanCallbacks
#else
  using BLEAdvertisedDeviceCallbacks = NimBLEAdvertisedDeviceCallbacks;
#endif
