#include <SD.h>
#include <SPI.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include "driver/gpio.h"
#include "Touchscreen.h"
#include "config.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_task_wdt.h"
#include "icon.h"
#include "gps.h"
#include "shared.h"
#include "utils.h"


bool notificationVisible = false;
static bool notificationHasSave = false;
static int notifX, notifY, notifWidth, notifHeight;
static int closeButtonX, closeButtonY, closeButtonSize = 16;
static int okButtonX, okButtonY, okButtonWidth = 84, okButtonHeight = 24;
static int saveButtonX, saveButtonY, saveButtonWidth = 84, saveButtonHeight = 24;

static char s_notifTitleCache[64];
static char s_notifMsgCache[400];
static bool s_notifShowSaveCache = false;

/** Wrapped line count for modal text (font 1, size 1 — must match draw path). */
static int countWrappedNotifLines(const String& msgIn, int innerPixelW) {
  tft.setTextFont(1);
  tft.setTextSize(1);
  String msg = msgIn;
  msg.trim();
  int lines = 0;
  while (msg.length() > 0 && lines < 48) {
    int lineEnd = msg.length();
    while (lineEnd > 0 && tft.textWidth(msg.substring(0, lineEnd)) > innerPixelW) {
      lineEnd--;
    }
    if (lineEnd <= 0) {
      ++lines;
      break;
    }
    if (lineEnd < msg.length()) {
      const int lastSpace = msg.substring(0, lineEnd).lastIndexOf(' ');
      if (lastSpace > 0) {
        lineEnd = lastSpace;
      }
    }
    ++lines;
    msg = msg.substring(lineEnd);
    msg.trim();
  }
  return lines;
}

static size_t decodeObfTo(char* out, size_t outSize, const uint8_t* in, size_t inLen, uint8_t key) {
  if (!out || outSize == 0) return 0;
  size_t n = inLen;
  if (n > outSize - 1) n = outSize - 1;
  for (size_t i = 0; i < n; ++i) out[i] = (char)(in[i] ^ key);
  out[n] = '\0';
  return n;
}

void tftPrintObf(const uint8_t* data, size_t len, uint8_t key) {
  char buf[96];
  decodeObfTo(buf, sizeof(buf), data, len, key);
  tft.print(buf);
}

void tftPrintlnObf(const uint8_t* data, size_t len, uint8_t key) {
  char buf[96];
  decodeObfTo(buf, sizeof(buf), data, len, key);
  tft.println(buf);
}

void serialPrintObf(const uint8_t* data, size_t len, bool newline, uint8_t key) {
  char buf[128];
  decodeObfTo(buf, sizeof(buf), data, len, key);
  if (newline) Serial.println(buf);
  else Serial.print(buf);
}

static inline bool inRect(int x, int y, int rx, int ry, int rw, int rh) {
  return x >= rx && x < (rx + rw) && y >= ry && y < (ry + rh);
}

static void drawNotificationInternal(const char* title, const char* message, bool showSave) {
    snprintf(s_notifTitleCache, sizeof(s_notifTitleCache), "%s", title ? title : "");
    snprintf(s_notifMsgCache, sizeof(s_notifMsgCache), "%s", message ? message : "");
    s_notifShowSaveCache = showSave;
    notificationHasSave = showSave;

    const int scrW = tft.width();
    const int scrH = tft.height();
    notifWidth = (scrW > 232) ? 224 : (scrW - 16);
    if (notifWidth < 160) {
        notifWidth = 160;
    }

    const int messageBoxWidth = notifWidth - 10;
    const int innerTextW = messageBoxWidth - 6;
    const int lineH = 12;
    const int footH = showSave ? 40 : 30;
    const int topBand = 25;

    tft.setTextFont(1);
    tft.setTextSize(1);
    String msgProbe = message ? String(message) : String("");
    msgProbe.trim();
    int lineCount = countWrappedNotifLines(msgProbe, innerTextW);
    if (lineCount < 2) {
        lineCount = 2;
    }
    const int maxLinesByScreen = (scrH - topBand - footH - 14) / lineH;
    int useLines = lineCount;
    if (useLines > maxLinesByScreen) {
        useLines = maxLinesByScreen > 2 ? maxLinesByScreen : 2;
    }

    const int messageBoxHeight = 8 + useLines * lineH;
    notifHeight = topBand + messageBoxHeight + footH;
    if (notifHeight > scrH - 8) {
        notifHeight = scrH - 8;
        const int availBody = notifHeight - topBand - footH;
        useLines = (availBody - 8) / lineH;
        if (useLines < 2) {
            useLines = 2;
        }
    }
    notifX = (scrW - notifWidth) / 2;
    notifY = (scrH - notifHeight) / 2;
    if (notifY < 4) {
        notifY = 4;
    }

    tft.fillRect(notifX, notifY, notifWidth, notifHeight, LIGHT_GRAY);
    tft.drawRect(notifX, notifY, notifWidth, notifHeight, DARK_GRAY);
    tft.fillRect(notifX, notifY, notifWidth, 20, BLUE);

    tft.setTextColor(WHITE, BLUE);
    tft.setTextSize(1);
    tft.setCursor(notifX + 6, notifY + 5);
    tft.print(title);

    closeButtonX = notifX + notifWidth - closeButtonSize - 6;
    closeButtonY = notifY + 3;
    tft.fillRect(closeButtonX, closeButtonY, closeButtonSize, closeButtonSize, RED);
    tft.setTextColor(WHITE, RED);
    tft.setCursor(closeButtonX + 5, closeButtonY + 4);
    tft.print("X");

    int messageBoxX = notifX + 5;
    int messageBoxY = notifY + 25;
    const int messageBoxDrawH = notifHeight - topBand - footH;
    tft.fillRect(messageBoxX, messageBoxY, messageBoxWidth, messageBoxDrawH, WHITE);
    tft.setTextColor(BLACK, WHITE);

    {
      const int maxY = messageBoxY + messageBoxDrawH - lineH;
      String msg = message ? String(message) : String("");
      msg.trim();
      int cursorX = messageBoxX + 3;
      int cursorY = messageBoxY + 4;
      while (msg.length() > 0 && cursorY <= maxY) {
        int lineEnd = msg.length();
        while (lineEnd > 0 && tft.textWidth(msg.substring(0, lineEnd)) > innerTextW) {
          lineEnd--;
        }
        if (lineEnd <= 0) {
          break;
        }
        if (lineEnd < msg.length()) {
          int lastSpace = msg.substring(0, lineEnd).lastIndexOf(' ');
          if (lastSpace > 0) {
            lineEnd = lastSpace;
          }
        }
        tft.setCursor(cursorX, cursorY);
        tft.print(msg.substring(0, lineEnd));
        msg = msg.substring(lineEnd);
        msg.trim();
        cursorY += lineH;
      }

      if (msg.length() > 0) {
        tft.setCursor(cursorX, maxY);
        tft.print("...");
      }
    }

    int btnY = notifY + notifHeight - 25;
    if (showSave) {
      okButtonWidth = 72;
      saveButtonWidth = 72;
      okButtonHeight = saveButtonHeight = 20;
      okButtonX = notifX + 10;
      saveButtonX = notifX + notifWidth - 10 - saveButtonWidth;
      okButtonY = saveButtonY = btnY;

      tft.fillRect(okButtonX, okButtonY, okButtonWidth, okButtonHeight, GRAY);
      tft.drawRect(okButtonX, okButtonY, okButtonWidth, okButtonHeight, DARK_GRAY);
      tft.drawLine(okButtonX, okButtonY, okButtonX + okButtonWidth, okButtonY, WHITE);
      tft.drawLine(okButtonX, okButtonY, okButtonX, okButtonY + okButtonHeight, WHITE);
      tft.setTextColor(BLACK, GRAY);
      tft.setCursor(okButtonX + 28, okButtonY + 5);
      tft.print("OK");

      tft.fillRect(saveButtonX, saveButtonY, saveButtonWidth, saveButtonHeight, GREEN);
      tft.drawRect(saveButtonX, saveButtonY, saveButtonWidth, saveButtonHeight, DARK_GRAY);
      tft.drawLine(saveButtonX, saveButtonY, saveButtonX + saveButtonWidth, saveButtonY, WHITE);
      tft.drawLine(saveButtonX, saveButtonY, saveButtonX, saveButtonY + saveButtonHeight, WHITE);
      tft.setTextColor(BLACK, GREEN);
      tft.setCursor(saveButtonX + 18, saveButtonY + 5);
      tft.print("SAVE");
    } else {
      okButtonWidth = 72;
      okButtonHeight = 20;
      okButtonX = notifX + (notifWidth - okButtonWidth) / 2;
      okButtonY = btnY;
      tft.fillRect(okButtonX, okButtonY, okButtonWidth, okButtonHeight, GRAY);
      tft.drawRect(okButtonX, okButtonY, okButtonWidth, okButtonHeight, DARK_GRAY);
      tft.drawLine(okButtonX, okButtonY, okButtonX + okButtonWidth, okButtonY, WHITE);
      tft.drawLine(okButtonX, okButtonY, okButtonX, okButtonY + okButtonHeight, WHITE);
      tft.setTextColor(BLACK, GRAY);
      tft.setCursor(okButtonX + 28, okButtonY + 5);
      tft.print("OK");
    }

    notificationVisible = true;
}

void showNotificationActions(const char* title, const char* message, bool showSave) {
    drawNotificationInternal(title, message, showSave);
}

void showNotification(const char* title, const char* message) {
    drawNotificationInternal(title, message, false);
}

void hideNotification() {
    applyThemeToPalette(settings().theme);
    tft.fillRect(notifX, notifY, notifWidth, notifHeight, UI_BG);
    notificationVisible = false;
}

bool isNotificationVisible() { return notificationVisible; }

void notificationRedrawIfVisible() {
    if (!notificationVisible) {
        return;
    }
    drawNotificationInternal(s_notifTitleCache, s_notifMsgCache, s_notifShowSaveCache);
}

NotificationAction notificationHandleTouch(int x, int y) {
  if (!notificationVisible) return NotificationAction::None;

  if (inRect(x, y, closeButtonX, closeButtonY, closeButtonSize, closeButtonSize)) {
    hideNotification();
    return NotificationAction::Close;
  }
  if (inRect(x, y, okButtonX, okButtonY, okButtonWidth, okButtonHeight)) {
    hideNotification();
    return NotificationAction::Ok;
  }
  if (notificationHasSave && inRect(x, y, saveButtonX, saveButtonY, saveButtonWidth, saveButtonHeight)) {
    hideNotification();
    return NotificationAction::Save;
  }
  return NotificationAction::None;
}

void printWrappedText(int x, int y, int maxWidth, const char* text) {
    String message = text;
    int cursorX = x, cursorY = y;

    while (message.length() > 0) {
        int lineEnd = message.length();

        while (tft.textWidth(message.substring(0, lineEnd)) > maxWidth) {
            lineEnd--;
        }

        if (lineEnd < message.length()) {
            int lastSpace = message.substring(0, lineEnd).lastIndexOf(' ');
            if (lastSpace > 0) lineEnd = lastSpace;
        }

        tft.setCursor(cursorX, cursorY);
        tft.print(message.substring(0, lineEnd));

        message = message.substring(lineEnd);
        message.trim();

        cursorY += 15;
    }
}

namespace FeatureUI {

#ifndef FEATURE_TEXT
#define FEATURE_TEXT ORANGE
#endif

static inline uint16_t btnFill(ButtonStyle style, bool pressed, bool disabled) {
  if (disabled) return UI_LINE;
  if (pressed)  return UI_FG;
  switch (style) {
    case ButtonStyle::Primary:   return FEATURE_TEXT;
    case ButtonStyle::Secondary: return UI_FG;
    case ButtonStyle::Danger:    return UI_WARN;
  }
  return UI_FG;
}

static inline uint16_t btnBorder(ButtonStyle style, bool disabled) {
  if (disabled) return UI_LINE;
  switch (style) {
    case ButtonStyle::Primary:   return FEATURE_TEXT;
    case ButtonStyle::Secondary: return FEATURE_TEXT;
    case ButtonStyle::Danger:    return UI_WARN;
  }
  return FEATURE_TEXT;
}

static inline uint16_t btnText(ButtonStyle style, bool disabled) {
  if (disabled) return UI_TEXT;

  switch (style) {
    case ButtonStyle::Secondary: return UI_ICON;
    case ButtonStyle::Primary:
    case ButtonStyle::Danger:    return FEATURE_BG;
  }
  return UI_ICON;
}

void drawFooterBg() {

  tft.fillRect(0, tft.height() - FOOTER_H, tft.width(), FOOTER_H, FEATURE_BG);
}

void drawButtonRect(int x, int y, int w, int h,
                    const char* label,
                    ButtonStyle style,
                    bool pressed,
                    bool disabled,
                    uint8_t font) {
  if (!label) label = "";
  int r = h / 2;
  if (r > 6) r = 6;
  if (r < 0) r = 0;
  uint16_t fill = btnFill(style, pressed, disabled);
  uint16_t edge = btnBorder(style, disabled);
  uint16_t txt  = btnText(style, disabled);

  tft.fillRoundRect(x, y, w, h, r, fill);
  tft.drawRoundRect(x, y, w, h, r, edge);

  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(txt, fill);

  tft.drawString(label, x + w/2, y + h/2, font);

  tft.setTextDatum(TL_DATUM);
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(UI_TEXT, FEATURE_BG);
}

void layoutFooter3(Button (&btns)[3],
                   const char* l0, ButtonStyle s0,
                   const char* l1, ButtonStyle s1,
                   const char* l2, ButtonStyle s2,
                   bool d0, bool d1, bool d2) {
  int availW = tft.width() - 2*PAD_X;
  int w = (availW - 2*GAP_X) / 3;
  int y = tft.height() - FOOTER_H + (FOOTER_H - BTN_H)/2;
  int x0 = PAD_X;
  int x1 = x0 + w + GAP_X;
  int x2 = x1 + w + GAP_X;
  btns[0] = {(int16_t)x0,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l0,s0,d0};
  btns[1] = {(int16_t)x1,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l1,s1,d1};
  btns[2] = {(int16_t)x2,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l2,s2,d2};
}

void layoutFooter2(Button (&btns)[2],
                   const char* l0, ButtonStyle s0,
                   const char* l1, ButtonStyle s1,
                   bool d0, bool d1) {
  int availW = tft.width() - 2*PAD_X;
  int w = (availW - GAP_X) / 2;
  int y = tft.height() - FOOTER_H + (FOOTER_H - BTN_H)/2;
  int x0 = PAD_X;
  int x1 = x0 + w + GAP_X;
  btns[0] = {(int16_t)x0,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l0,s0,d0};
  btns[1] = {(int16_t)x1,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l1,s1,d1};
}

void layoutFooter4(Button (&btns)[4],
                   const char* l0, ButtonStyle s0,
                   const char* l1, ButtonStyle s1,
                   const char* l2, ButtonStyle s2,
                   const char* l3, ButtonStyle s3,
                   bool d0, bool d1, bool d2, bool d3) {
  int availW = tft.width() - 2*PAD_X;
  int w = (availW - 3*GAP_X) / 4;
  int y = tft.height() - FOOTER_H + (FOOTER_H - BTN_H)/2;
  int x0 = PAD_X;
  int x1 = x0 + w + GAP_X;
  int x2 = x1 + w + GAP_X;
  int x3 = x2 + w + GAP_X;
  btns[0] = {(int16_t)x0,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l0,s0,d0};
  btns[1] = {(int16_t)x1,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l1,s1,d1};
  btns[2] = {(int16_t)x2,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l2,s2,d2};
  btns[3] = {(int16_t)x3,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l3,s3,d3};
}

void layoutFooter1(Button& btn, const char* label, ButtonStyle style, bool disabled) {
  int x = PAD_X;
  int w = tft.width() - 2*PAD_X;
  int y = tft.height() - FOOTER_H + (FOOTER_H - BTN_H)/2;
  btn = {(int16_t)x,(int16_t)y,(int16_t)w,(int16_t)BTN_H,label,style,disabled};
}

void layoutFooter5(Button (&btns)[5],
                   const char* l0, ButtonStyle s0,
                   const char* l1, ButtonStyle s1,
                   const char* l2, ButtonStyle s2,
                   const char* l3, ButtonStyle s3,
                   const char* l4, ButtonStyle s4,
                   bool d0, bool d1, bool d2, bool d3, bool d4) {
  int availW = tft.width() - 2*PAD_X;
  int w = (availW - 4*GAP_X) / 5;
  int y = tft.height() - FOOTER_H + (FOOTER_H - BTN_H)/2;
  int x0 = PAD_X;
  int x1 = x0 + w + GAP_X;
  int x2 = x1 + w + GAP_X;
  int x3 = x2 + w + GAP_X;
  int x4 = x3 + w + GAP_X;
  btns[0] = {(int16_t)x0,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l0,s0,d0};
  btns[1] = {(int16_t)x1,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l1,s1,d1};
  btns[2] = {(int16_t)x2,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l2,s2,d2};
  btns[3] = {(int16_t)x3,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l3,s3,d3};
  btns[4] = {(int16_t)x4,(int16_t)y,(int16_t)w,(int16_t)BTN_H,l4,s4,d4};
}

int hit(const Button* btns, int n, int x, int y) {
  for (int i = 0; i < n; ++i) {
    const auto& b = btns[i];
    if (x >= b.x && x <= (b.x + b.w) && y >= b.y && y <= (b.y + b.h)) return i;
  }
  return -1;
}

}

unsigned long lastStatusBarUpdate = 0;
const int STATUS_BAR_UPDATE_INTERVAL = 2000;
float lastBatteryVoltage = 0.0;
bool sdCardPresent = false;
bool lastSdCardState = false;

static TaskHandle_t statusBarTaskHandle = nullptr;
static volatile bool statusBarDirty = true;
static constexpr uint32_t kStatusBarWardBlinkHalfMs = 900;

void requestStatusBarRedraw() {
  statusBarDirty = true;
}

const float R1 = 100000.0;
const float R2 = 100000.0;

float readBatteryVoltage()
{
#if !defined(BATTERY_ADC_PIN) || BATTERY_ADC_PIN < 0
  // CYD (and S3 default) has no battery voltage divider wired to any ADC pin.
  // Calling analogSetPinAttenuation(-1, ...) on Core 3.x / IDF5 causes the
  // ADC driver to spam "adc_io_to_channel: invalid gpio number" and can crash.
  // Return a fixed "USB powered" value so the status bar stays happy.
  return 5.0f;
#else
  static bool adcInitialized = false;
  if (!adcInitialized)
  {
    analogSetPinAttenuation(BATTERY_ADC_PIN, ADC_11db);
    adcInitialized = true;
  }

  const int sampleCount = 16;
  uint32_t sum = 0;
  for (int i = 0; i < sampleCount; i++)
  {
    sum += analogReadMilliVolts(BATTERY_ADC_PIN);
    delayMicroseconds(500);
  }
  return (sum / (float)sampleCount / 1000.0f) * 2.0f;
#endif
}

float readInternalTemperature() {
  float temperature = temperatureRead();
  return temperature;
}

void updateSdCardStatus() {

#ifdef SD_CD
  bool cardDetected = !digitalRead(SD_CD);
#else
  bool cardDetected = true;
#endif

  if (cardDetected != lastSdCardState) {
    sdCardPresent = cardDetected;
    lastSdCardState = cardDetected;

    Serial.println(sdCardPresent ? "SD Card detected" : "SD Card removed");
    requestStatusBarRedraw();
  }
}

static bool statusBarBatteryMeaningfulChange(int newPct, int oldPct, bool force) {
  if (force || oldPct == -1) {
    return true;
  }
  if (newPct <= 25 || oldPct <= 25) {
    return newPct != oldPct;
  }
  const int d = newPct - oldPct;
  return (d >= 3 || d <= -3);
}

static int statusBarTempBand(float t) {
  if (fabs(static_cast<double>(t) - 53.33) < 0.51) {
    return 1;
  }
  if (t > 55.f) {
    return 2;
  }
  return 0;
}

void drawStatusBar(float batteryVoltage, bool forceUpdate, bool bottomSeparator) {
  static int lastBatteryPercentage = -1;
  static int lastWifiHalf          = -100000;
  static int lastBleHalf           = -100000;
  static int lastTempBand          = -100;
  static int lastSdSnap            = -1;
  static bool lastWardGpsIcon      = false;
  static uint32_t lastWardBlinkPhase = 0;

  int batteryPercentage = ::map(batteryVoltage * 100, 300, 420, 0, 100);
  batteryPercentage = constrain(batteryPercentage, 0, 100);

  int wifiDevices = 0;
  int bleDevices  = 0;

  wifiDevices = WifiScan::getLastCount();
  bleDevices  = BleScan::getLastCount();

  const int wifiHalf = wifiDevices / 2;
  const int bleHalf  = bleDevices / 2;

  const bool wardGpsIcon = GpsWardriver::statusBarGpsIconActive();
  const uint32_t wardBlinkPhase =
      wardGpsIcon ? (millis() / kStatusBarWardBlinkHalfMs) : 0u;
  const bool wardSatVisible =
      wardGpsIcon && ((wardBlinkPhase & 1u) == 0u);

  const float internalTemp = readInternalTemperature();
  const int tempBand         = statusBarTempBand(internalTemp);
  const int sdSnap           = sdCardPresent ? 1 : 0;

  const bool battCh =
      statusBarBatteryMeaningfulChange(batteryPercentage, lastBatteryPercentage, forceUpdate);
  const bool wardBlinkOnly =
      !forceUpdate && wardGpsIcon && lastWardGpsIcon &&
      (wardBlinkPhase != lastWardBlinkPhase) && !battCh && wifiHalf == lastWifiHalf &&
      bleHalf == lastBleHalf && tempBand == lastTempBand && sdSnap == lastSdSnap;

  if (wardBlinkOnly) {
    constexpr int kBarH   = 20;
    constexpr int kY      = 4;
    constexpr int kIconY  = kY - 2;
    constexpr int kIconW  = 16;
    constexpr int kGap    = 3;
    constexpr int kBleIx  = 130;
    constexpr int kBleDrawX = kBleIx + 25;
    const int wardGpsX    = kBleDrawX - kGap - kIconW;
    if (wardSatVisible) {
      tft.drawBitmap(wardGpsX, kIconY, bitmap_icon_satellite, kIconW, kIconW, TFT_ORANGE);
    } else {
      tft.fillRect(wardGpsX, kIconY, kIconW, kIconW, UI_LABLE);
    }
    if (bottomSeparator) {
      tft.drawFastHLine(0, kBarH - 1, tft.width(), TFT_WHITE);
    }
    lastWardBlinkPhase = wardBlinkPhase;
    return;
  }

  if (battCh || wifiHalf != lastWifiHalf || bleHalf != lastBleHalf || tempBand != lastTempBand ||
      sdSnap != lastSdSnap || wardGpsIcon != lastWardGpsIcon ||
      (wardGpsIcon && wardBlinkPhase != lastWardBlinkPhase) || forceUpdate) {
    int barHeight = 20;
    int x = 7;
    int y = 4;

    tft.fillRect(0, 0, tft.width(), barHeight, UI_LABLE);

    tft.drawRoundRect(x, y, 22, 10, 2, TFT_WHITE);
    tft.fillRect(x + 22, y + 3, 2, 4, TFT_WHITE);

    int batteryLevelWidth = ::map(batteryPercentage, 0, 100, 0, 20);
    uint16_t batteryColor = (batteryPercentage > 20) ? GREEN : TFT_RED;
    tft.fillRoundRect(x + 2, y + 2, batteryLevelWidth, 6, 1, batteryColor);

    tft.setCursor(x + 30, y + 2);
    tft.setTextColor(GREEN, UI_LABLE);
    tft.setTextFont(1);
    tft.setTextSize(1);
    tft.print(String(batteryPercentage) + "%");

    const int iconW         = 16;
    const int gap           = 3;
    const int wifiBarsWidth = 24;

    const int bleIconX      = 130;
    const int bleTextX      = bleIconX + iconW + gap;
    const int wifiBarsX     = bleTextX + 12 + gap;
    const int tempIconX     = wifiBarsX + wifiBarsWidth + gap;
    const int sdIconX       = tempIconX + iconW + gap;
    int iconY               = y - 2;

    int clearWidth = tft.width() - bleIconX;
    tft.fillRect(bleIconX, 0, clearWidth, barHeight, UI_LABLE);

    const int bleDrawX = bleIconX + 25;
    if (wardSatVisible) {
      const int wardGpsX = bleDrawX - gap - iconW;
      tft.drawBitmap(wardGpsX, iconY, bitmap_icon_satellite, iconW, iconW, TFT_ORANGE);
    }

    uint16_t wifiColor = (wifiDevices > 0) ? GREEN : TFT_WHITE;
    uint16_t bleColor  = (bleDevices  > 0) ? TFT_CYAN  : TFT_WHITE;

    int wifiStrength = 0;
    if (wifiDevices > 0) {

      wifiStrength = constrain(::map(wifiDevices, 0, 15, 0, 100), 0, 100);
    }

    int wifiX = wifiBarsX + 10;
    int wifiY = y + 11;

    for (int i = 0; i < 4; i++) {
      const int sigBarH = (i + 1) * 3;
      const int barWidth  = 4;
      const int barX      = wifiX + i * 6;

      if (wifiStrength > i * 25) {
        tft.fillRoundRect(barX, wifiY - sigBarH, barWidth, sigBarH, 1, GREEN);
      } else {
        tft.drawRoundRect(barX, wifiY - sigBarH, barWidth, sigBarH, 1, TFT_WHITE);
      }
    }

    tft.drawBitmap(bleIconX + 25, iconY, bitmap_icon_ble, 16, 16, bleColor);
    tft.setTextColor(bleColor, UI_LABLE);

    if (internalTemp == 53.33f) {
      tft.drawBitmap(tempIconX + 10, y - 2, bitmap_icon_temp, 16, 16, TFT_YELLOW);
    } else if (internalTemp > 55) {
      tft.drawBitmap(tempIconX + 10, y - 2, bitmap_icon_temp, 16, 16, TFT_RED);
    } else {
      tft.drawBitmap(tempIconX + 10, y - 2, bitmap_icon_temp, 16, 16, GREEN);
    }

    if (sdCardPresent) {
      tft.drawBitmap(sdIconX + 10, y - 2, bitmap_icon_sdcard, 16, 16, GREEN);
    } else {
      tft.drawBitmap(sdIconX + 10, y - 2, bitmap_icon_nullsdcard, 16, 16, TFT_RED);
    }

    if (bottomSeparator) {
      tft.drawFastHLine(0, barHeight - 1, tft.width(), TFT_WHITE);
    }

    lastBatteryPercentage = batteryPercentage;
    lastWifiHalf          = wifiHalf;
    lastBleHalf           = bleHalf;
    lastTempBand          = tempBand;
    lastSdSnap            = sdSnap;
    lastWardGpsIcon       = wardGpsIcon;
    lastWardBlinkPhase    = wardGpsIcon ? wardBlinkPhase : 0u;
  }
}

static void statusBarTask(void* ) {
  static int prevBattPct    = -1;
  static int prevWifiHalf   = -100000;
  static int prevBleHalf    = -100000;
  static int prevTempBand   = -100;
  static int prevSdSnap     = -1;
  static bool prevWardIcon  = false;
  static uint32_t prevWardPhase = 0;

  for (;;) {
    updateSdCardStatus();
    const float v = readBatteryVoltage();
    currentBatteryVoltage = v;

    const int pct = constrain(::map((int)(v * 100.f), 300, 420, 0, 100), 0, 100);
    const int wifi  = WifiScan::getLastCount();
    const int ble   = BleScan::getLastCount();
    const int wifiH = wifi / 2;
    const int bleH  = ble / 2;
    const int tBand = statusBarTempBand(readInternalTemperature());
    const int sdSn  = sdCardPresent ? 1 : 0;
    const bool ward = GpsWardriver::statusBarGpsIconActive();
    const uint32_t wPh = ward ? (millis() / kStatusBarWardBlinkHalfMs) : 0u;

    bool need = false;
    if (statusBarBatteryMeaningfulChange(pct, prevBattPct, false)) {
      need = true;
    }
    if (wifiH != prevWifiHalf || bleH != prevBleHalf) {
      need = true;
    }
    if (tBand != prevTempBand || sdSn != prevSdSnap) {
      need = true;
    }
    if (ward != prevWardIcon) {
      need = true;
    }
    if (ward && wPh != prevWardPhase) {
      need = true;
    }

    if (need) {
      statusBarDirty = true;
      prevBattPct     = pct;
      prevWifiHalf    = wifiH;
      prevBleHalf     = bleH;
      prevTempBand    = tBand;
      prevSdSnap      = sdSn;
      prevWardIcon    = ward;
      prevWardPhase   = ward ? wPh : 0u;
    }

    vTaskDelay(pdMS_TO_TICKS(400));
  }
}

void startStatusBarTask() {
  if (statusBarTaskHandle != nullptr) return;
  xTaskCreatePinnedToCore(
    statusBarTask,
    "statusBar",
    2048,
    nullptr,
    1,
    &statusBarTaskHandle,
    0
  );
}

void pauseBackgroundRadioTasks() {
  GpsWardriver::stopBackgroundIfRunning();
}

void updateStatusBar() {

  if (statusBarTaskHandle != nullptr) {
    if (statusBarDirty) {
      drawStatusBar(currentBatteryVoltage, false);
      statusBarDirty = false;
    }
    return;
  }

  const unsigned long currentMillis = millis();
  const bool wardOn = GpsWardriver::statusBarGpsIconActive();
  static uint32_t s_noTaskLastWardPhase = UINT32_MAX;
  const uint32_t wardPh =
      wardOn ? (currentMillis / kStatusBarWardBlinkHalfMs) : 0u;
  const bool wardBlinkTick =
      wardOn && (s_noTaskLastWardPhase == UINT32_MAX || wardPh != s_noTaskLastWardPhase);
  if (wardOn) {
    s_noTaskLastWardPhase = wardPh;
  } else {
    s_noTaskLastWardPhase = UINT32_MAX;
  }

  if (currentMillis - lastStatusBarUpdate > STATUS_BAR_UPDATE_INTERVAL || wardBlinkTick) {
    float batteryVoltage = readBatteryVoltage();
    updateSdCardStatus();
    currentBatteryVoltage = batteryVoltage;
    drawStatusBar(batteryVoltage, false);
    lastBatteryVoltage = batteryVoltage;
    lastStatusBarUpdate = currentMillis;
  }
}

#if HAS_PCF8574_BUTTONS
static uint8_t s_pcf8574Addr = 0;

uint8_t getPcf8574Address() {
  return s_pcf8574Addr;
}

bool initPcf8574Buttons() {
  // Prevent I2C bus hangs (no ACK / missing pull-ups) from tripping the task WDT
  // and rebooting right after the intro on classic ESP32.
  Wire.begin();
  Wire.setTimeOut(50);

  pcf.pinMode(BTN_UP, INPUT_PULLUP);
  pcf.pinMode(BTN_DOWN, INPUT_PULLUP);
  pcf.pinMode(BTN_LEFT, INPUT_PULLUP);
  pcf.pinMode(BTN_RIGHT, INPUT_PULLUP);
  pcf.pinMode(BTN_SELECT, INPUT_PULLUP);

#if PCF8574_AUTO_DETECT
  for (uint8_t addr = PCF8574_ADDR_MIN; addr <= PCF8574_ADDR_MAX; addr++) {
    yield();
    if (pcf.begin(addr)) {
      s_pcf8574Addr = addr;
      Serial.printf("[PCF8574] auto-detected at 0x%02X\n", addr);
      break;
    }
  }
  if (s_pcf8574Addr == 0) {
    Serial.println("[PCF8574] not found (scanned 0x20-0x27)");
    return false;
  }
#else
  if (!pcf.begin(PCF8574_I2C_ADDR)) {
    Serial.printf("[PCF8574] not found at fixed address 0x%02X\n", PCF8574_I2C_ADDR);
    return false;
  }
  s_pcf8574Addr = PCF8574_I2C_ADDR;
  Serial.printf("[PCF8574] using fixed address 0x%02X\n", s_pcf8574Addr);
#endif

  return true;
}
#else
uint8_t getPcf8574Address() {
  return 0;
}

bool initPcf8574Buttons() {
  return false;
}
#endif

#if TOUCH_SHARES_TFT_SPI
#if defined(CONFIG_IDF_TARGET_ESP32S3)
static SPIClass s_sdSpi(FSPI);
#elif defined(CONFIG_IDF_TARGET_ESP32)
static SPIClass s_sdSpi(VSPI);
#else
static SPIClass s_sdSpi(FSPI);
#endif
#elif defined(BOARD_CYD)
// CYD: SD is on VSPI (18/19/23/CS=5), TFT is on HSPI (14/12/13/CS=15).
// Use an explicit VSPI SPIClass instead of the global SPI object so Core 3.x
// cannot accidentally confuse the two hardware SPI controllers.
static SPIClass s_sdSpi(VSPI);
#endif

/** Tracks whether SD.begin() currently owns a live mount on the shared SPI bus. */
static bool s_sdFsMounted = false;

/** GPIO CS that last mounted SD (-1 = unknown). Tried first to avoid long SD.begin on wrong CS. */
static int8_t s_sdLastGoodCs = -1;

/** After a failed mount on classic ESP32, do not keep retrying (SD.begin can WDT). */
static bool s_sdMountGaveUp = false;
// Forward decl — definition is 160 lines below, but callers in initSDCard()
// appear first. Must keep it static so it doesn't pollute the global namespace.
static bool sdTryBeginOrder();

void sdRetryMount() {
  s_sdMountGaveUp = false;
}

/** Deselect every other SPI slave that shares the SD bus so none holds MISO. */
static void sdRaiseCsPin(int pin) {
  if (pin < 0) {
    return;
  }
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
}

static void sdReleaseOtherChipSelects() {
#if defined(CC1101_CS)
  sdRaiseCsPin(CC1101_CS);
#endif
#if defined(PN532_SS)
  sdRaiseCsPin(PN532_SS);
#endif
#if defined(CSN_PIN_1)
  sdRaiseCsPin(CSN_PIN_1);
#endif
#if defined(CSN_PIN_2)
  sdRaiseCsPin(CSN_PIN_2);
#endif
#if defined(CSN_PIN_3)
  sdRaiseCsPin(CSN_PIN_3);
#endif
  // Scanner bit-bangs CE/CSN on these pins; keep CE low / CSN high after leaving.
#if defined(CE_PIN_3)
  pinMode(CE_PIN_3, OUTPUT);
  digitalWrite(CE_PIN_3, LOW);
#endif
}

void sdSpiInit() {
#if defined(SD_SCLK) && defined(SD_MISO) && defined(SD_MOSI) && defined(SD_CS)
#if TOUCH_SHARES_TFT_SPI || defined(BOARD_CYD)
  s_sdSpi.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
#else
  // On ESP32-S3 (v2), RFID bitbang remaps these pins — reset before reclaim.
  // On classic ESP32 (v1), SD often shares SPI with TFT_eSPI; gpio_reset_pin
  // after tft.init() can WDT/reboot during boot SD mount.
#if BOARD_HAS_ESP32S3
  gpio_reset_pin((gpio_num_t)SD_SCLK);
  gpio_reset_pin((gpio_num_t)SD_MISO);
  gpio_reset_pin((gpio_num_t)SD_MOSI);
  gpio_reset_pin((gpio_num_t)SD_CS);
#endif
  SPI.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
  SPI.setDataMode(SPI_MODE0);
  SPI.setBitOrder(MSBFIRST);
  SPI.setFrequency(4000000);
#endif
#endif
}

bool sdMountChipSelect(uint8_t cs) {
#if TOUCH_SHARES_TFT_SPI || defined(BOARD_CYD)
  // Use the dedicated SPIClass instance (explicit VSPI on CYD) so Core 3.x
  // never confuses this bus with the TFT's HSPI.
  return SD.begin(cs, s_sdSpi, 4000000);
#else
  return SD.begin(cs, SPI, 4000000);
#endif
}

void initSDCard() {

#ifdef SD_CD
  pinMode(SD_CD, INPUT_PULLUP);
#endif

#if defined(BOARD_CYD)
  // CYD SD is on its own VSPI bus (SCK=18 MISO=19 MOSI=23 CS=5).
  // TFT is on HSPI (SCK=14 MISO=12 MOSI=13 CS=15) — completely separate.
  // We use an explicit SPIClass(VSPI) instance (s_sdSpi) so Core 3.x never
  // confuses the two SPI hardware controllers.

  // Feed WDT before the SD init — SD.begin() on Core 3.x with a slow or
  // poorly-formatted card can take >1 s and trigger a watchdog reset.
  yield();
  esp_task_wdt_reset();

  sdSpiInit();                  // begin s_sdSpi (VSPI)
  sdReleaseOtherChipSelects();
  delay(50);                    // give the card VCC / SPI lines time to settle

  yield();
  esp_task_wdt_reset();

  if (sdTryBeginOrder()) {
    s_sdFsMounted = true;
    Serial.println("[sd] CYD VSPI SD mounted OK");
  } else {
    Serial.println("[sd] CYD SD not found (no card, wrong format, or wiring)");
    // Don't set s_sdMountGaveUp — allow a lazy retry when a feature first
    // asks for SD (user may insert the card after boot).
  }
  updateSdCardStatus();

#elif !BOARD_HAS_ESP32S3
  // V1 classic ESP32: SD shares SPI with TFT — full SD.begin at this point
  // was rebooting the board right after the intro ("3 sd" crash).
  // Raise CS only; a lazy remount happens the first time a feature asks.
#if defined(SD_CS)
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);
#endif
  sdReleaseOtherChipSelects();
  s_sdMountGaveUp = true;   // suppress auto-retries that would WDT
  updateSdCardStatus();
  return;

#else
  // S3 (V2): dedicated SPI buses, full mount at boot.
  restoreSdAfterSharedSpi();
  updateSdCardStatus();
#endif
}

static bool sdPinIsOkForSdMount(uint8_t pin) {
#if defined(SD_CS)
  if (pin == SD_CS) {
    return true;
  }
#endif
#if defined(SD_CS_PIN)
#if defined(CC1101_CS)
  if (SD_CS_PIN != CC1101_CS && pin == SD_CS_PIN) {
    return true;
  }
#else
  if (pin == SD_CS_PIN) {
    return true;
  }
#endif
#endif
  return false;
}

static void sdAddPinUnique(uint8_t* pins, int* nTry, uint8_t p) {
  if (!sdPinIsOkForSdMount(p)) {
    return;
  }
  for (int j = 0; j < *nTry; j++) {
    if (pins[j] == p) {
      return;
    }
  }
  if (*nTry < 3) {
    pins[(*nTry)++] = p;
  }
}

/** SPI must already be SD wiring. Returns true if SD.begin succeeded. */
static bool sdTryBeginOrder() {
  uint8_t tryPins[3];
  int nTry = 0;
  if (s_sdLastGoodCs >= 0) {
    sdAddPinUnique(tryPins, &nTry, (uint8_t)s_sdLastGoodCs);
  }
#if defined(SD_CS)
  sdAddPinUnique(tryPins, &nTry, SD_CS);
#endif
#if defined(SD_CS_PIN)
#if defined(CC1101_CS)
  if (SD_CS_PIN != CC1101_CS) {
    sdAddPinUnique(tryPins, &nTry, SD_CS_PIN);
  }
#else
  sdAddPinUnique(tryPins, &nTry, SD_CS_PIN);
#endif
#endif
  for (int i = 0; i < nTry; i++) {
    if (sdMountChipSelect(tryPins[i])) {
      s_sdLastGoodCs = (int8_t)tryPins[i];
      return true;
    }
  }
  s_sdLastGoodCs = -1;
  return false;
}

/** Soft remount: keep current SPI pinmux. Safe while CC1101/nRF24 still need the bus
 *  (same SCK/MISO/MOSI as SD on DIV V2). Only raises other chip-selects and remounts FatFS. */
static bool sdRemountSoft() {
  sdReleaseOtherChipSelects();

#if defined(SD_SCLK) && defined(SD_MISO) && defined(SD_MOSI) && defined(SD_CS)
#if TOUCH_SHARES_TFT_SPI || defined(BOARD_CYD)
  s_sdSpi.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
#else
  // Do not SPI.end()/gpio_reset here — that tears down CC1101 after SubGHz Init.
  SPI.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
  SPI.setDataMode(SPI_MODE0);
  SPI.setBitOrder(MSBFIRST);
#endif
#endif

  SD.end();
  s_sdFsMounted = false;
  delay(2);
  if (sdTryBeginOrder()) {
    s_sdFsMounted = true;
#if !TOUCH_SHARES_TFT_SPI
    // SD.begin() often leaves the bus at 16–40 MHz; CC1101 cannot use that.
    SPI.setFrequency(4000000);
#endif
    return true;
  }
  return false;
}

bool isSDCardAvailable() {
#ifdef SD_CD
  updateSdCardStatus();
  if (!sdCardPresent) {
    return false;
  }
#endif

  // FatFS "exists(/)" can stay true after another feature stole the SPI bus.
  // cardType() actually talks to the card and catches a dead mount.
  if (s_sdFsMounted) {
    if (SD.cardType() != CARD_NONE) {
      return true;
    }
    s_sdFsMounted = false;
    SD.end();
  }

  // V1 only: mounting was proven to WDT-crash on first use; don't retry.
  // CYD has its own dedicated VSPI bus for SD — allow retries.
#if !BOARD_HAS_ESP32S3 && !defined(BOARD_CYD)
  if (s_sdMountGaveUp) {
    return false;
  }
#endif

  // Prefer a soft remount so SubGHz (CC1101 on the same SPI pins) stays alive.
  if (sdRemountSoft()) {
    return true;
  }

  // Soft failed — pins may still be in RFID bitbang / Scanner remapped state.
  // Only do the destructive reclaim when no radio feature owns the bus.
  if (!feature_active) {
    restoreSdAfterSharedSpi();
#if !BOARD_HAS_ESP32S3 && !defined(BOARD_CYD)
    if (!s_sdFsMounted) {
      s_sdMountGaveUp = true;
      Serial.println("[sd] mount failed — will not retry until reboot");
    }
#endif
    return s_sdFsMounted;
  }
  return false;
}

void holdSdInactiveOnSharedSpi() {
#if defined(SD_CS)
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);
#endif
#if !TOUCH_SHARES_TFT_SPI
  SPI.setDataMode(SPI_MODE0);
  SPI.setBitOrder(MSBFIRST);
  SPI.setFrequency(4000000);
#endif
}

void reclaimSharedSpiBus() {
  // Reset pinmux after RFID bitbang / Scanner remaps, but do NOT SD.begin().
  // Mounting SD here is what broke SubGHz: SD.begin raises SPI clock and parks
  // the card on the same MISO line CC1101 needs.
  sdReleaseOtherChipSelects();
#if defined(SD_CS)
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);
#endif
#if defined(CC1101_CS)
  pinMode(CC1101_CS, OUTPUT);
  digitalWrite(CC1101_CS, HIGH);
#endif
#if defined(PN532_SS)
  pinMode(PN532_SS, OUTPUT);
  digitalWrite(PN532_SS, HIGH);
#endif

  SD.end();
  s_sdFsMounted = false;

#if !TOUCH_SHARES_TFT_SPI
  SPI.end();
#if BOARD_HAS_ESP32S3
#if defined(SD_SCLK) && defined(SD_MISO) && defined(SD_MOSI)
  gpio_reset_pin((gpio_num_t)SD_SCLK);
  gpio_reset_pin((gpio_num_t)SD_MISO);
  gpio_reset_pin((gpio_num_t)SD_MOSI);
#endif
  // PN532 software-SPI may have bitbanged these (on DIV V2 MOSI/MISO are
  // swapped vs SD/CC1101). Reset them even when they overlap SD pins.
#if defined(PN532_SCK)
  gpio_reset_pin((gpio_num_t)PN532_SCK);
#endif
#if defined(PN532_MISO)
  gpio_reset_pin((gpio_num_t)PN532_MISO);
#endif
#if defined(PN532_MOSI)
  gpio_reset_pin((gpio_num_t)PN532_MOSI);
#endif
#if defined(PN532_SS)
  gpio_reset_pin((gpio_num_t)PN532_SS);
  pinMode(PN532_SS, OUTPUT);
  digitalWrite(PN532_SS, HIGH);
#endif
#if defined(SD_CS)
  gpio_reset_pin((gpio_num_t)SD_CS);
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);
#endif
#if defined(CC1101_CS)
  gpio_reset_pin((gpio_num_t)CC1101_CS);
  pinMode(CC1101_CS, OUTPUT);
  digitalWrite(CC1101_CS, HIGH);
#endif
#endif // BOARD_HAS_ESP32S3
#if defined(SD_SCLK) && defined(SD_MISO) && defined(SD_MOSI) && defined(SD_CS)
#if defined(CC1101_SCK) && defined(CC1101_MISO) && defined(CC1101_MOSI) && defined(CC1101_CS)
  // Prefer CC1101 CS as SPI SS — same data pins as SD on DIV V2, but matches
  // what ELECHOUSE SpiStart() will bind on the next Init().
  SPI.begin(CC1101_SCK, CC1101_MISO, CC1101_MOSI, CC1101_CS);
#else
  SPI.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
#endif
  SPI.setDataMode(SPI_MODE0);
  SPI.setBitOrder(MSBFIRST);
  SPI.setFrequency(4000000);
#endif
#else
#if defined(SD_SCLK) && defined(SD_MISO) && defined(SD_MOSI) && defined(SD_CS)
  s_sdSpi.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);
#endif
#endif
  delay(2);
}

void restoreSdAfterSharedSpi() {
  // Full reclaim + remount for menu/SD features after leaving SPI radios.
  reclaimSharedSpiBus();
  delay(5);
  if (sdTryBeginOrder()) {
    s_sdFsMounted = true;
#if !TOUCH_SHARES_TFT_SPI
    SPI.setFrequency(4000000);
#endif
  }
  requestStatusBarRedraw();
}

void loading(int frameDelay, uint16_t color, int16_t x, int16_t y, int repeats, bool center) {
  int16_t bitmapWidth = 100;
  int16_t bitmapHeight = 120;
  int16_t logoX = x;
  int16_t logoY = y;

  if (center) {
    int16_t screenWidth = tft.width();
    int16_t screenHeight = tft.height();
    logoX = (screenWidth - bitmapWidth) / 2;
    logoY = (screenHeight - bitmapHeight) / 2;
  }

  const unsigned char* bitmaps[] = {
    bitmap_icon_skull_loading_1,
    bitmap_icon_skull_loading_2,
    bitmap_icon_skull_loading_3,
    bitmap_icon_skull_loading_4,
    bitmap_icon_skull_loading_5,
    bitmap_icon_skull_loading_6,
    bitmap_icon_skull_loading_7,
    bitmap_icon_skull_loading_8,
    bitmap_icon_skull_loading_9,
    bitmap_icon_skull_loading_10
  };
  const int numFrames = 10;

  // On the CYD "inverted colors" panel, TFT_INVERSION_ON is set in
  // User_Setup.h so tft.init() sends INVON.  Every color we draw is
  // hardware-inverted before it hits the panel:
  //   drawn BLACK (0x0000) → shows WHITE
  //   drawn WHITE (0xFFFF) → shows BLACK
  //   drawn RED   (0xF800) → shows CYAN
  // We pre-invert the boot-screen palette here so the skulls look correct
  // (white skull on black background, red banner) WITHOUT any runtime
  // tft.invertDisplay() call, which only appeared to work because settings
  // weren't loaded yet during the animation.
#ifdef BOARD_CYD
  const uint16_t BG_FILL   = TFT_WHITE;  // shown as BLACK  (inverted)
  const uint16_t SKULL_CLR = TFT_BLACK;  // shown as WHITE  (inverted)
  const uint16_t BNRTXT    = TFT_CYAN;   // shown as RED    (inverted)
  const uint16_t BNRBG     = TFT_WHITE;  // shown as BLACK  (inverted)
  (void)color; // ignore whatever the caller passed – pre-inverted is correct
#else
  const uint16_t BG_FILL   = TFT_BLACK;
  const uint16_t SKULL_CLR = color;
  const uint16_t BNRTXT    = TFT_RED;
  const uint16_t BNRBG     = TFT_BLACK;
#endif

  for (int r = 0; r < repeats; r++) {
    for (int i = 0; i < numFrames; i++) {
      tft.fillRect(logoX, logoY, bitmapWidth, bitmapHeight, BG_FILL);
      tft.drawBitmap(logoX, logoY, bitmaps[i], bitmapWidth, bitmapHeight, SKULL_CLR);
#if defined(SHOW_PORT_BANNER) && SHOW_PORT_BANNER
      {
        const char* banner = PORT_BANNER_TEXT;
        tft.setTextFont(2);
        tft.setTextSize(1);
        int tw = (int)tft.textWidth(banner);
        int bx = (tft.width() - tw) / 2;
        int by = max(2, logoY - 20);
        tft.fillRect(0, by - 2, tft.width(), 16, BNRBG);
        tft.setTextColor(BNRTXT, BNRBG);
        tft.setCursor(bx, by);
        tft.print(banner);
      }
#endif
      delay(frameDelay);
    }
  }
}

void displayLogo(uint16_t color, int displayTime) {
  int16_t bitmapWidth = 150;
  int16_t bitmapHeight = 150;
  int16_t screenWidth = tft.width();
  int16_t screenHeight = tft.height();
  int16_t logoX = (screenWidth - bitmapWidth) / 2;
  int16_t logoY = (screenHeight - bitmapHeight) / 2 - 20;

#ifdef BOARD_CYD
  // Pre-invert: drawn WHITE → shows BLACK bg, drawn BLACK → shows WHITE logo
  const uint16_t dLBg  = TFT_WHITE;
  const uint16_t dLFg  = TFT_BLACK;
  (void)color;
#else
  const uint16_t dLBg  = TFT_BLACK;
  const uint16_t dLFg  = color;
#endif
  tft.fillRect(logoX, logoY, bitmapWidth, bitmapHeight, dLBg);
  tft.drawBitmap(logoX, logoY, bitmap_icon_cifer, bitmapWidth, bitmapHeight, dLFg);

  tft.setTextColor(dLFg);
  tft.setTextFont(1);

  tft.setTextSize(2);
  int16_t textX = screenWidth / 3.5;
  int16_t textY = logoY + bitmapHeight + 10;
  tft.setCursor(textX, textY);
  tftPrintObf(OBF_PN, sizeof(OBF_PN));

  tft.setTextSize(1);
  textX = screenWidth / 3.5;
  textY += 20;
  tft.setCursor(textX, textY);
  tft.print("by ");
  tftPrintObf(OBF_DN, sizeof(OBF_DN));

  textX = screenWidth / 2.5;
  textY += 50;
  tft.setCursor(textX, textY);
  // Version is intentionally NOT obfuscated.
  tft.print(ESP32DIV_VERSION);

  Serial.println("==================================");
  serialPrintObf(OBF_PN, sizeof(OBF_PN), true);
  Serial.print("Developed by: "); serialPrintObf(OBF_DN, sizeof(OBF_DN), true);
  // Version is intentionally NOT obfuscated.
  Serial.print("Version:      "); Serial.println(ESP32DIV_VERSION);
  Serial.print("Contact:      "); serialPrintObf(OBF_EM, sizeof(OBF_EM), true);
  Serial.print("GitHub:       "); serialPrintObf(OBF_GH, sizeof(OBF_GH), true);
  Serial.print("Website:      "); serialPrintObf(OBF_WB, sizeof(OBF_WB), true);
  Serial.println("==================================");

  delay(displayTime);
}

namespace Terminal {

#define TEXT_HEIGHT 16
#define BOT_FIXED_AREA 0
#define TOP_FIXED_AREA 86
#define DISPLAY_WIDTH 240
#define DISPLAY_HEIGHT 320
#define SCREEN_WIDTH 240
#define SCREENHEIGHT 320

static bool uiDrawn = false;

uint16_t yStart = TOP_FIXED_AREA;
uint16_t yArea = DISPLAY_HEIGHT - TOP_FIXED_AREA - BOT_FIXED_AREA;
uint16_t yDraw = DISPLAY_HEIGHT - BOT_FIXED_AREA - TEXT_HEIGHT;

uint16_t xPos = 0;

byte data = 0;

boolean change_colour = 1;
boolean selected = 1;
boolean terminalActive = true;

int blank[19];

long baudRates[] = {9600, 19200, 38400, 57600, 115200};
byte baudIndex = 0;

static int terminalContentBottom() {
  return featureHasTouchNavBar() ? (int)touchNavContentBottomY() : DISPLAY_HEIGHT;
}

static int terminalBotFixedArea() {
  const int bottom = terminalContentBottom();
  return (bottom < DISPLAY_HEIGHT) ? (DISPLAY_HEIGHT - bottom) : BOT_FIXED_AREA;
}

static void terminalUpdateNavLabels() {
  if (!featureHasTouchNavBar()) {
    return;
  }
  setTouchNavLabels("Exit", nullptr, terminalActive ? "Pause" : "Active", nullptr, "Baud");
  redrawTouchButtonBar();
}

static void terminalCycleBaud() {
  if (terminalActive) {
    terminalActive = false;
    terminalUpdateNavLabels();
    return;
  }
  baudIndex = (baudIndex + 1) % 5;
  Serial.end();
  delay(100);
  Serial.begin(baudRates[baudIndex]);
  tft.fillRect(0, 37, DISPLAY_WIDTH, 16, ORANGE);
  tft.setTextColor(TFT_WHITE, TFT_WHITE);
  String baudMsg = " Serial Terminal - " + String(baudRates[baudIndex]) + " baud ";
  tft.drawCentreString(baudMsg, DISPLAY_WIDTH / 2, 37, 2);
  delay(10);
}

static void terminalSetActive(bool active) {
  terminalActive = active;
  delay(10);
  tft.fillRect(0, 37, DISPLAY_WIDTH, 16, ORANGE);
  tft.setTextColor(TFT_WHITE, TFT_WHITE);
  if (active) {
    tft.drawCentreString(" Serial Terminal Active ", DISPLAY_WIDTH / 2, 37, 2);
  } else {
    String baudMsg = " Serial Terminal - " + String(baudRates[baudIndex]) + " baud ";
    tft.drawCentreString(baudMsg, DISPLAY_WIDTH / 2, 37, 2);
  }
  terminalUpdateNavLabels();
}

static void terminalHandleNavButtons() {
  if (!featureHasTouchNavBar()) {
    return;
  }
  if (isTouchNavButtonPressedEdge(BTN_LEFT)) {
    feature_exit_requested = true;
    return;
  }
  if (isTouchNavButtonPressedEdge(BTN_RIGHT)) {
    terminalCycleBaud();
    return;
  }
  if (isTouchNavButtonPressedEdge(BTN_SELECT)) {
    terminalSetActive(!terminalActive);
  }
}

void runUI() {

    #define STATUS_BAR_Y_OFFSET 20
    #define STATUS_BAR_HEIGHT 16
    #define ICON_SIZE 16
    #define ICON_NUM 3

    static int iconX[ICON_NUM] = {210, 170, 10};
    static int iconY = STATUS_BAR_Y_OFFSET;

    static const unsigned char* icons[ICON_NUM] = {
        bitmap_icon_sort_up_plus,
        bitmap_icon_power,
        bitmap_icon_go_back
    };

    if (!uiDrawn) {
        tft.drawLine(0, 19, 240, 19, TFT_WHITE);
        tft.fillRect(0, STATUS_BAR_Y_OFFSET, SCREEN_WIDTH, STATUS_BAR_HEIGHT, DARK_GRAY);

        for (int i = 0; i < ICON_NUM; i++) {
            if (icons[i] != NULL) {
                tft.drawBitmap(iconX[i], iconY, icons[i], ICON_SIZE, ICON_SIZE, TFT_WHITE);
            }
        }
        tft.drawLine(0, STATUS_BAR_Y_OFFSET + STATUS_BAR_HEIGHT, SCREEN_WIDTH, STATUS_BAR_Y_OFFSET + STATUS_BAR_HEIGHT, ORANGE);
        uiDrawn = true;
    }

    static unsigned long lastAnimationTime = 0;
    static int animationState = 0;
    static int activeIcon = -1;

    if (animationState > 0 && millis() - lastAnimationTime >= 150) {
        if (animationState == 1) {
            tft.drawBitmap(iconX[activeIcon], iconY, icons[activeIcon], ICON_SIZE, ICON_SIZE, TFT_WHITE);
            animationState = 2;

            switch (activeIcon) {
                case 0:
                  if (terminalActive) {
                    terminalActive = false;
                  } else if (!terminalActive) {
                    baudIndex = (baudIndex + 1) % 5;
                    Serial.end();
                    delay(100);
                    Serial.begin(baudRates[baudIndex]);
                    tft.fillRect(0, 37, DISPLAY_WIDTH, 16, ORANGE);
                    tft.setTextColor(TFT_WHITE, TFT_WHITE);
                    String baudMsg = " Serial Terminal - " + String(baudRates[baudIndex]) + " baud ";
                    tft.drawCentreString(baudMsg, DISPLAY_WIDTH / 2, 37, 2);
                    delay(10);
                  }
                    break;
                case 1:
                    delay(10);
                    tft.fillRect(0, 37, DISPLAY_WIDTH, 16, ORANGE);
                    tft.setTextColor(TFT_WHITE, TFT_WHITE);
                    tft.drawCentreString(" Serial Terminal Active ", DISPLAY_WIDTH / 2, 37, 2);
                    terminalActive = true;
                    break;

                case 2:
                    feature_exit_requested = true;
                    break;
            }
        } else if (animationState == 2) {
            animationState = 0;
            activeIcon = -1;
        }
        lastAnimationTime = millis();
    }

    static unsigned long lastTouchCheck = 0;
    const unsigned long touchCheckInterval = 50;

    if (millis() - lastTouchCheck >= touchCheckInterval) {
        int x, y;
        if (!featureHasTouchNavBar() && feature_active && readTouchXY(x, y)) {
            if (y > STATUS_BAR_Y_OFFSET && y < STATUS_BAR_Y_OFFSET + STATUS_BAR_HEIGHT) {
                for (int i = 0; i < ICON_NUM; i++) {
                    if (x > iconX[i] && x < iconX[i] + ICON_SIZE) {
                        if (icons[i] != NULL && animationState == 0) {
                            tft.drawBitmap(iconX[i], iconY, icons[i], ICON_SIZE, ICON_SIZE, TFT_BLACK);
                            animationState = 1;
                            activeIcon = i;
                            lastAnimationTime = millis();
                        }
                        break;
                    }
                }
            }
        }
        lastTouchCheck = millis();
    }
}

void scrollAddress(uint16_t vsp) {
  tft.writecommand(ILI9341_VSCRSADD);
  tft.writedata(vsp >> 8);
  tft.writedata(vsp);
}

int scroll_line() {
  int yTemp = yStart;
  tft.fillRect(0, yStart, blank[(yStart - TOP_FIXED_AREA) / TEXT_HEIGHT], TEXT_HEIGHT, TFT_BLACK);

  yStart += TEXT_HEIGHT;
  const int scrollLimit = DISPLAY_HEIGHT - terminalBotFixedArea();
  if (yStart >= scrollLimit) {
    yStart = TOP_FIXED_AREA + (yStart - scrollLimit);
  }
  scrollAddress(yStart);
  delay(1);
  return yTemp;
}

void setupScrollArea(uint16_t tfa, uint16_t bfa) {
  tft.writecommand(ILI9341_VSCRDEF);
  tft.writedata(tfa >> 8);
  tft.writedata(tfa);
  tft.writedata((DISPLAY_HEIGHT - tfa - bfa) >> 8);
  tft.writedata(DISPLAY_HEIGHT - tfa - bfa);
  tft.writedata(bfa >> 8);
  tft.writedata(bfa);
}

void terminalSetup() {

  setupTouchscreen();
  tft.fillScreen(TFT_BLACK);

  tft.fillRect(0, 37, DISPLAY_WIDTH, 16, ORANGE);
  tft.setTextColor(TFT_WHITE, TFT_WHITE);
  String baudMsg = " Serial Terminal - " + String(baudRates[baudIndex]) + " baud ";
  tft.drawCentreString(baudMsg, DISPLAY_WIDTH / 2, 37, 2);

  float currentBatteryVoltage = readBatteryVoltage();

  drawStatusBar(currentBatteryVoltage, true);

  uiDrawn = false;

  Serial.begin(baudRates[baudIndex]);

  const int bfa = terminalBotFixedArea();
  yArea = DISPLAY_HEIGHT - TOP_FIXED_AREA - bfa;
  yDraw = DISPLAY_HEIGHT - bfa - TEXT_HEIGHT;
  setupScrollArea(TOP_FIXED_AREA, bfa);

  for (byte i = 0; i < 19; i++) blank[i] = 0;

  terminalUpdateNavLabels();
}

void terminalLoop() {

  updateStatusBar();
  if (featureHasTouchNavBar()) {
    maintainTouchNavBar();
  }
  terminalHandleNavButtons();
  runUI();

  if (terminalActive) {
    byte charCount = 0;
    while (Serial.available() && charCount < 10) {
      data = Serial.read();
      if (data == '\r' || xPos > 231) {
        xPos = 0;
        yDraw = scroll_line();
      }
      if (data > 31 && data < 128) {
        xPos += tft.drawChar(data, xPos, yDraw, 2);
        blank[(18 + (yStart - TOP_FIXED_AREA) / TEXT_HEIGHT) % 19] = xPos;
      }
      charCount++;
      }
    }
  }
}

namespace AppSettingsUI {

static const int SCREEN_W = 240;
static const int BAR_H    = 22;
static const int TITLE_Y  = BAR_H + 4;
static const int TITLE_H  = 16;
static const int ROW_H    = 32;
static const int GAP_Y    = 4;
static const int PAD_X    = 12;
static const int LABEL_W  = 92;
static const int RADIUS   = 8;

static inline int rowY(int i) { return TITLE_Y + TITLE_H + 6 + i * (ROW_H + GAP_Y); }

struct Rect { int x,y,w,h; };
static inline Rect makeRect(int x,int y,int w,int h){ return {x,y,w,h}; }
static inline void fillRound(const Rect& r, uint16_t c){ tft.fillRoundRect(r.x,r.y,r.w,r.h,RADIUS,c); }
static inline void drawRound(const Rect& r, uint16_t c){ tft.drawRoundRect(r.x,r.y,r.w,r.h,RADIUS,c); }

static uint16_t cardBG, cardEdge, textDim, textStrong, accentSoft, btnBg, btnFg, btnStroke;

static uint16_t blend565(uint16_t a, uint16_t b, uint8_t k ) {
  uint32_t rb = (((a & 0xF81F) * (255-k)) + ((b & 0xF81F) * k)) >> 8;
  uint32_t g  = (((a & 0x07E0) * (255-k)) + ((b & 0x07E0) * k)) >> 8;
  return (rb & 0xF81F) | (g & 0x07E0);
}
static void buildPalette() {

  cardBG     = UI_FG;
  cardEdge   = UI_LINE;
  textDim    = UI_TEXT;
  textStrong = UI_TEXT;
  accentSoft = UI_ICON;

  btnBg      = UI_BG;
  btnFg      = UI_FG;
  btnStroke  = UI_LINE;
}

static int  sel = 0;
static bool dirtySettings = false;
static bool uiDirty = false;

// Row order: 0=Brightness 1=Theme 2=Accent 3=NeoPixel 4=AutoScan 5=InvertDisplay
static const char* items[] = {
  "Brightness",
  "Theme",
  "Accent",
  "NeoPixel",
  "Auto Scan",
  "Invert Display",   // ← row 5: applies tft.invertDisplay() immediately
};
static const int N = sizeof(items)/sizeof(items[0]);

static uint8_t  last_brightness;
static Theme    last_theme;
static uint8_t  last_accent;
static bool     last_neopixel;
static bool     last_autoScan;
static bool     last_invert;
static int      last_sel;

static bool dragging = false;

static uint32_t lastChangeMs = 0;

static Rect rowRect(int i) { return makeRect(PAD_X, rowY(i), SCREEN_W - PAD_X*2, ROW_H); }

static void setTitleFont() { tft.setTextFont(2); }
static void setLabelFont() { tft.setTextFont(2); }

static void drawTitle() {
  setTitleFont();
  tft.setTextColor(textStrong, UI.bg);
  tft.setCursor(PAD_X, TITLE_Y);
  tft.print("Settings");
}

static void drawCardStatic(int i, bool selected) {
  Rect r = rowRect(i);

  tft.fillRect(0, r.y, SCREEN_W, r.h, UI_BG);

  if (selected) {
    tft.fillRect(0, r.y, 3, r.h, UI.accent);
  }

  setLabelFont();
  tft.setTextColor(textDim, UI_BG);
  int ty = r.y + (r.h/2 - 6);
  tft.setCursor(r.x, ty);
  tft.print(items[i]);

  tft.drawLine(PAD_X, r.y + r.h - 1, SCREEN_W - PAD_X, r.y + r.h - 1, UI_LINE);
}

static void wipeBrightnessWidgetArea() {
  Rect r = rowRect(0);
  tft.fillRect(r.x + LABEL_W, r.y + 2, r.w - LABEL_W - 6, r.h - 4, UI_BG);
}
static void wipeThemeWidgetArea() {
  Rect r = rowRect(1);
  tft.fillRect(r.x + LABEL_W, r.y + 2, r.w - LABEL_W - 6, r.h - 4, UI_BG);
}
static void wipeAccentWidgetArea() {
  Rect r = rowRect(2);
  tft.fillRect(r.x + LABEL_W, r.y + 2, r.w - LABEL_W - 6, r.h - 4, UI_BG);
}
static void wipeSwitchWidgetArea(int row) {
  Rect r = rowRect(row);
  tft.fillRect(r.x + LABEL_W, r.y + 2, r.w - LABEL_W - 6, r.h - 4, UI_BG);
}

static Rect rBrightTrack(){
  Rect r = rowRect(0);
  int left  = r.x + LABEL_W + 6;
  int right = r.x + r.w - 44;
  int w     = max(70, right - left);
  return makeRect(left, r.y + (r.h/2 - 8), w, 16);
}
static Rect rBrightKnob(uint8_t v) {
  Rect tr = rBrightTrack();
  int d = 18;
  int x = tr.x + (int)((uint32_t)v * (tr.w - d) / 255u);
  int y = tr.y + tr.h/2 - d/2;
  return makeRect(x, y, d, d);
}
static void drawBrightnessWidget(uint8_t v, bool selected) {
  tft.startWrite();
  wipeBrightnessWidgetArea();

  Rect tr = rBrightTrack();

  tft.fillRoundRect(tr.x, tr.y, tr.w, tr.h, tr.h/2, UI_BG);
  tft.drawRoundRect(tr.x, tr.y, tr.w, tr.h, tr.h/2, cardEdge);

  int fw = (int)((uint32_t)v * tr.w / 255u);
  tft.fillRoundRect(tr.x, tr.y, fw+2, tr.h, tr.h/2, UI_ICON);

  Rect kb = rBrightKnob(v);
  tft.fillCircle(kb.x + kb.w/2, kb.y + kb.h/2, kb.w/2, UI_FG);
  tft.drawCircle(kb.x + kb.w/2, kb.y + kb.h/2, kb.w/2, selected ? UI_ICON : UI_FG);

  int bx = tr.x + tr.w + 6, by = tr.y - 2, bw = 34, bh = tr.h + 4;
  tft.fillRoundRect(bx+1, by+1, bw, bh, 4, blend565(UI_BG, UI_FG, 28));
  tft.fillRoundRect(bx,   by,   bw, bh, 4, cardBG);
  tft.drawRoundRect(bx,   by,   bw, bh, 4, cardEdge);
  setLabelFont();
  tft.setTextColor(textStrong, cardBG);
  char buf[8]; snprintf(buf,sizeof(buf),"%3u", v);
  tft.setCursor(bx+5, by+2);
  tft.print(buf);

  tft.endWrite();
}
static void drawBrightness(uint8_t v, bool selected) {
  drawCardStatic(0, selected);
  drawBrightnessWidget(v, selected);
}

static Rect rThemeDark()  {
  Rect r = rowRect(1);
  int right = r.x + r.w - 6;
  tft.setTextFont(2);
  int wD = (int)tft.textWidth("[Dark]");
  int wL = (int)tft.textWidth("Light");
  int gap = 6;
  return makeRect(right - wD - gap - wL, r.y + 8, wD, r.h - 16);
}
static Rect rThemeLight() {
  Rect r = rowRect(1);
  int right = r.x + r.w - 6;
  tft.setTextFont(2);
  int wL = (int)tft.textWidth("[Light]");
  return makeRect(right - wL, r.y + 8, wL, r.h - 16);
}

static void drawThemeWidget(Theme th, bool ) {

  tft.startWrite();
  wipeThemeWidgetArea();

  Rect r = rowRect(1);
  int right = r.x + r.w - 6;
  int ty    = r.y + (r.h / 2 - 6);

  setLabelFont();

  const char* darkLabel  = (th == Theme::Dark)  ? "[Dark]"  : "Dark";
  const char* lightLabel = (th == Theme::Light) ? "[Light]" : "Light";

  int wD = (int)tft.textWidth(darkLabel);
  int wL = (int)tft.textWidth(lightLabel);
  int gap = 6;

  int lx = right - wL;
  int dx = lx - gap - wD;

  tft.setTextColor(textStrong, UI_BG);
  tft.setCursor(dx, ty);
  tft.print(darkLabel);
  tft.setCursor(lx, ty);
  tft.print(lightLabel);

  tft.endWrite();
}
static void drawTheme(Theme th, bool selected) {
  drawCardStatic(1, selected);
  drawThemeWidget(th, selected);
}

static Rect rAccentSwatch() {
  Rect r = rowRect(2);
  int sw = 18;
  int sx = r.x + r.w - sw - 6;
  int sy = r.y + (r.h - sw) / 2;
  return makeRect(sx, sy, sw, sw);
}
static void drawAccentWidget(uint8_t preset, bool ) {
  tft.startWrite();
  wipeAccentWidgetArea();

  Rect r = rowRect(2);
  int right = r.x + r.w - 6;
  int ty = r.y + (r.h / 2 - 6);

  setLabelFont();
  const char* name = accentPresetName(preset);
  int nameW = (int)tft.textWidth(name);
  Rect sw = rAccentSwatch();
  int nameX = sw.x - 8 - nameW;

  tft.setTextColor(textStrong, UI_BG);
  tft.setCursor(nameX, ty);
  tft.print(name);

  // Duo-tone swatch — left half = primary, right half = secondary.
  // Gives a quick "gradient pair" preview without needing actual gradients.
  const uint16_t ca = accentColor565(preset);
  const uint16_t cb = accentColor565_b(preset);
  const int half = sw.w / 2;
  tft.fillRoundRect(sw.x,        sw.y, half,        sw.h, 4, ca);
  tft.fillRect     (sw.x + half, sw.y, sw.w - half, sw.h, cb);  // square right edge
  tft.drawRoundRect(sw.x, sw.y, sw.w, sw.h, 4, cardEdge);
  tft.drawFastVLine(sw.x + half, sw.y + 2, sw.h - 4, UI_BG);  // subtle divider

  tft.endWrite();
}
static void drawAccent(uint8_t preset, bool selected) {
  drawCardStatic(2, selected);
  drawAccentWidget(preset, selected);
}

static Rect rSwitchTrack(int row){
  Rect r = rowRect(row);
  const int w = 34;
  const int h = 14;
  int x = r.x + r.w - w - 10;
  int y = r.y + (r.h - h) / 2;
  return makeRect(x, y, w, h);
}
static Rect rSwitchKnob(bool on, int row) {
  Rect tr = rSwitchTrack(row);
  int d = tr.h - 4;
  int x = on ? (tr.x + tr.w - d - 2)
             : (tr.x + 2);
  int y = tr.y + (tr.h - d) / 2;
  return makeRect(x, y, d, d);
}
static void drawSwitchWidgetRow(bool on, bool , int row) {
  tft.startWrite();
  wipeSwitchWidgetArea(row);

  Rect tr = rSwitchTrack(row);

  tft.fillRoundRect(tr.x, tr.y, tr.w, tr.h, tr.h/2, UI_BG);
  tft.drawRoundRect(tr.x, tr.y, tr.w, tr.h, tr.h/2, cardEdge);

  if (on) {
    tft.fillRoundRect(tr.x+1, tr.y+1, tr.w-2, tr.h-2, tr.h/2, UI_ICON);
  }

  Rect kb = rSwitchKnob(on, row);
  uint16_t knobBody  = UI_FG;
  uint16_t knobEdge  = on ? UI.accent : UI_FG;
  tft.fillCircle(kb.x+kb.w/2, kb.y+kb.h/2, kb.w/2, knobBody);
  tft.drawCircle(kb.x+kb.w/2, kb.y+kb.h/2, kb.w/2, knobEdge);

  setLabelFont();
  tft.setTextColor(textStrong, UI_BG);
  int labelX = tr.x - 26;
  int labelY = tr.y + 1;
  tft.setCursor(labelX, labelY);
  tft.print(on ? "ON" : "OFF");

  tft.endWrite();
}
static void drawSwitchRow(bool on, bool selected, int row) {
  drawCardStatic(row, selected);
  drawSwitchWidgetRow(on, selected, row);
}

static void drawNeoPixel   (bool on, bool selected) { drawSwitchRow(on, selected, 3); }
static void drawAutoScan   (bool on, bool selected) { drawSwitchRow(on, selected, 4); }
static void drawInvertDisplay(bool on, bool selected) {
  // Draw the standard switch row, then append a small "(live)" hint so the
  // user knows the effect is instant — they don't need to press Save first.
  drawSwitchRow(on, selected, 5);
  Rect r  = rowRect(5);
  Rect tr = rSwitchTrack(5);
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(UI_LINE, UI_BG);
  tft.setCursor(tr.x - 56, r.y + (r.h/2 - 3));
  tft.print("(live)");
}

static Rect backRect(){
  int h = tft.height();
  int bwTotal = SCREEN_W - PAD_X*2;
  int bh = 24;
  int bx = PAD_X;
  int by = h - bh - 8;
  const int gap = 8;
  int bw = (bwTotal - gap) / 2;
  return makeRect(bx, by, bw, bh);
}
static Rect saveRect(){
  Rect b = backRect();
  const int gap = 8;
  return makeRect(b.x + b.w + gap, b.y, b.w, b.h);
}
static void drawFooterButton(const Rect& b, const char* label, uint16_t body, uint16_t edge){

  FeatureUI::ButtonStyle style =
    (body == UI.accent) ? FeatureUI::ButtonStyle::Primary : FeatureUI::ButtonStyle::Secondary;
  FeatureUI::drawButtonRect(b.x, b.y, b.w, b.h, label, style);
}
static void footerToast(const char* msg, uint16_t color){
  Rect b = backRect();
  int y = b.y - 18;
  int h = 14;
  tft.fillRect(PAD_X, y, SCREEN_W - PAD_X*2, h, UI_BG);
  tft.setTextColor(color, UI_BG);
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setCursor(PAD_X, y + 3);
  tft.print(msg);
}
static void drawFooter(bool backPressed=false, bool savePressed=false){
  Rect b = backRect();
  Rect s = saveRect();

  int clearX = PAD_X - 2;
  int clearW = SCREEN_W - (PAD_X*2) + 4;
  tft.fillRect(clearX, b.y-2, clearW, b.h+4, UI.bg);

  FeatureUI::drawButtonRect(b.x, b.y, b.w, b.h, "Back",
                            backPressed ? FeatureUI::ButtonStyle::Primary : FeatureUI::ButtonStyle::Secondary);

  FeatureUI::drawButtonRect(s.x, s.y, s.w, s.h, "Save",
                            FeatureUI::ButtonStyle::Primary);
}
static bool touchInRect(const Rect& r, int x, int y) {
  return (x>=r.x && x<=r.x+r.w && y>=r.y && y<=r.y+r.h);
}

static void drawAll() {
  tft.fillScreen(UI_BG);
  buildPalette();

  drawStatusBar(currentBatteryVoltage, true);
  setTitleFont();
  drawTitle();

  auto& s = settings();
  drawBrightness(s.brightness, sel==0);
  drawTheme(s.theme, sel==1);
  drawAccent(s.accentColor, sel==2);
  drawNeoPixel(s.neopixelEnabled, sel==3);
  bool autoScan = (s.autoWifiScan || s.autoBleScan);
  drawAutoScan(autoScan, sel==4);
  drawInvertDisplay(s.tftInvertColors, sel==5);

  drawFooter(false, false);

  last_sel        = sel;
  last_brightness = s.brightness;
  last_theme      = s.theme;
  last_accent     = s.accentColor;
  last_neopixel   = s.neopixelEnabled;
  last_autoScan   = autoScan;
  last_invert     = s.tftInvertColors;
  uiDirty = false;
}

static void redrawIfChanged() {
  auto& s = settings();

  if (s.theme != last_theme || s.accentColor != last_accent) {
    applyThemeToPalette(s.theme);
    buildPalette();
    drawAll();
    return;
  }

  if (sel != last_sel) {
    drawCardStatic(0, sel==0);  drawBrightnessWidget(s.brightness, sel==0);
    drawCardStatic(1, sel==1);  drawThemeWidget(s.theme, sel==1);
    drawCardStatic(2, sel==2);  drawAccentWidget(s.accentColor, sel==2);
    drawCardStatic(3, sel==3);  drawSwitchWidgetRow(s.neopixelEnabled, sel==3, 3);
    bool autoScan = (s.autoWifiScan || s.autoBleScan);
    drawCardStatic(4, sel==4);  drawSwitchWidgetRow(autoScan, sel==4, 4);
    drawInvertDisplay(s.tftInvertColors, sel==5);
    last_sel = sel;
  } else {
    if (s.brightness != last_brightness) {
      drawBrightnessWidget(s.brightness, sel==0);
      last_brightness = s.brightness;
    }
    if (s.neopixelEnabled != last_neopixel) {
      drawSwitchWidgetRow(s.neopixelEnabled, sel==3, 3);
      last_neopixel = s.neopixelEnabled;
    }
    bool autoScan = (s.autoWifiScan || s.autoBleScan);
    if (autoScan != last_autoScan) {
      drawSwitchWidgetRow(autoScan, sel==4, 4);
      last_autoScan = autoScan;
    }
    if (s.theme != last_theme) {
      drawThemeWidget(s.theme, sel==1);
      last_theme = s.theme;
    }
    if (s.tftInvertColors != last_invert) {
      drawInvertDisplay(s.tftInvertColors, sel==5);
      last_invert = s.tftInvertColors;
    }
  }

  uiDirty = false;
}

static bool applyBrightness(uint8_t v){
  if (v > 255) v = 255;
  auto& s = settings();
  if (s.brightness == v) return false;
  s.brightness = v;
  ::setBrightness(v);
  dirtySettings = true;
  uiDirty = true;
  lastChangeMs = millis();
  return true;
}
static bool applyTheme(Theme t){
  auto& s = settings();
  if (s.theme == t) return false;
  s.theme = t;
  applyThemeToPalette(t);
  buildPalette();
  dirtySettings = true;
  uiDirty = true;
  lastChangeMs = millis();
  return true;
}
static bool applyAccent(uint8_t preset){
  auto& s = settings();
  preset = accentPresetClamp(preset);
  if (s.accentColor == preset) return false;
  s.accentColor = preset;
  applyThemeToPalette(s.theme);
  buildPalette();
  dirtySettings = true;
  uiDirty = true;
  lastChangeMs = millis();
  return true;
}
static bool applyNeoPixel(bool en){
  auto& s = settings();
  if (s.neopixelEnabled == en) return false;
  s.neopixelEnabled = en;
  dirtySettings = true;
  uiDirty = true;
  lastChangeMs = millis();
  return true;
}

static bool applyAutoScan(bool en){
  auto& s = settings();
  if (s.autoWifiScan == en && s.autoBleScan == en) return false;
  s.autoWifiScan = en;
  s.autoBleScan  = en;
  dirtySettings = true;
  uiDirty = true;
  lastChangeMs = millis();
  return true;
}

static bool applyInvert(bool en){
  auto& s = settings();
  if (s.tftInvertColors == en) return false;
  s.tftInvertColors = en;
  // Apply to the display hardware immediately — the user sees the result
  // before even pressing Save. The setting is persisted on the next Save.
  tft.invertDisplay(en);
  dirtySettings = true;
  uiDirty = true;
  lastChangeMs = millis();
  return true;
}

static void handleTouch() {
  int tx, ty;
  static uint32_t lastToggleMs = 0;
  static bool accentArmed = true;
  if (!readTouchXY(tx, ty)) {
    dragging = false;
    accentArmed = true;
    return;
  }

  Rect br = backRect();
  Rect sr = saveRect();
  if (touchInRect(br, tx, ty)) {
    drawFooter(true, false);
    delay(25);
    drawFooter(false, false);

    feature_exit_requested = true;
    return;
  }
  if (touchInRect(sr, tx, ty)) {
    drawFooter(false, true);
    delay(25);
    drawFooter(false, false);
    if (dirtySettings) {
      bool ok = settingsSave();
      if (ok) {
        dirtySettings = false;
        footerToast("Saved", UI.ok);
        delay(250);
        footerToast("      ", UI_BG);
      } else {
        footerToast("Save FAILED", UI.warn);
      }
    } else {
      footerToast("No changes", UI_TEXT);
      delay(250);
      footerToast("         ", UI_BG);
    }
    return;
  }

  for (int i=0;i<N;++i){
    Rect rr = rowRect(i);
    if (ty >= rr.y && ty <= rr.y+rr.h) { sel = i; break; }
  }

  auto& s = settings();

  if (sel == 0) {
    Rect tr = rBrightTrack();
    Rect kb = rBrightKnob(s.brightness);

    bool inTrack = (tx >= tr.x && tx <= tr.x+tr.w && ty >= tr.y-10 && ty <= tr.y+tr.h+10);
    bool inKnob  = (tx >= kb.x && tx <= kb.x+kb.w && ty >= kb.y && ty <= kb.y+kb.h);

    if (inTrack || inKnob) {
      dragging = true;
      long rel = tx - tr.x;
      if (rel < 0) rel = 0;
      if (rel > tr.w-1) rel = tr.w-1;
      uint8_t v = (uint8_t)((rel * 255L) / (tr.w - 1));
      applyBrightness(v);
    }
  } else if (sel == 1) {
    Rect d = rThemeDark();
    Rect l = rThemeLight();
    uint32_t now = millis();
    if (tx >= d.x && tx <= d.x+d.w && ty >= d.y && ty <= d.y+d.h) {
      if (now - lastToggleMs > 200) {
        applyTheme(Theme::Dark);
        lastToggleMs = now;
      }
    } else if (tx >= l.x && tx <= l.x+l.w && ty >= l.y && ty <= l.y+l.h) {
      if (now - lastToggleMs > 200) {
        applyTheme(Theme::Light);
        lastToggleMs = now;
      }
    }
  } else if (sel == 2) {
    Rect sw = rAccentSwatch();
    const bool onSwatch =
        (tx >= sw.x - 80 && tx <= sw.x + sw.w && ty >= sw.y - 8 && ty <= sw.y + sw.h + 8);
    if (onSwatch) {
      uint32_t now = millis();
      if (accentArmed && (now - lastToggleMs > 250)) {
        uint8_t next = (s.accentColor + 1) % ACCENT_PRESET_COUNT;
        applyAccent(next);
        lastToggleMs = now;
        accentArmed = false;
      }
    } else {
      accentArmed = true;
    }
  } else if (sel == 3) {
    Rect tr = rSwitchTrack(3);
    if (tx >= tr.x && tx <= tr.x+tr.w && ty >= tr.y-10 && ty <= tr.y+tr.h+10) {
      uint32_t now = millis();
      if (now - lastToggleMs > 120) {
        applyNeoPixel(!s.neopixelEnabled);
        lastToggleMs = now;
      }
    }
  } else if (sel == 4) {
    Rect tr = rSwitchTrack(4);
    if (tx >= tr.x && tx <= tr.x+tr.w && ty >= tr.y-10 && ty <= tr.y+tr.h+10) {
      uint32_t now = millis();
      if (now - lastToggleMs > 120) {
        bool autoScan = (s.autoWifiScan || s.autoBleScan);
        applyAutoScan(!autoScan);
        lastToggleMs = now;
      }
    }
  } else if (sel == 5) {
    Rect tr = rSwitchTrack(5);
    if (tx >= tr.x && tx <= tr.x+tr.w && ty >= tr.y-10 && ty <= tr.y+tr.h+10) {
      uint32_t now = millis();
      if (now - lastToggleMs > 180) {
        // applyInvert calls tft.invertDisplay() immediately — user sees the
        // result at once; Save persists it across reboots.
        applyInvert(!s.tftInvertColors);
        lastToggleMs = now;
        // After inversion the screen colors flip; redraw the full settings
        // screen so everything looks coherent again.
        drawAll();
      }
    }
  }
}

void setup(){

  applyThemeToPalette(settings().theme);
  buildPalette();
  ::setBrightness(settings().brightness);
  sel = 0; dirtySettings = false; uiDirty = false; dragging = false;
  drawAll();
}

void loop(){
  bool changedByButtons=false;

  static bool upWasDown     = false;
  static bool downWasDown   = false;
  static bool leftWasDown   = false;
  static bool rightWasDown  = false;
  static bool selectWasDown = false;
  static uint32_t lastNavMs = 0;
  static uint32_t lastActionMs = 0;
  const uint32_t NAV_DEBOUNCE_MS    = 140;
  const uint32_t ACTION_DEBOUNCE_MS = 140;

  uint32_t now = millis();

  bool upNow     = isButtonPressed(BTN_UP);
  bool downNow   = isButtonPressed(BTN_DOWN);
  bool leftNow   = isButtonPressed(BTN_LEFT);
  bool rightNow  = isButtonPressed(BTN_RIGHT);
  bool selectNow = isButtonPressed(BTN_SELECT);

  if (selectNow && !selectWasDown && (now - lastActionMs > ACTION_DEBOUNCE_MS)) {
    feature_exit_requested = true;
    lastActionMs = now;
    return;
  }

  if (upNow && !upWasDown && (now - lastNavMs > NAV_DEBOUNCE_MS)) {
    sel=(sel+N-1)%N; changedByButtons=true;
    lastNavMs = now;
  }
  if (downNow && !downWasDown && (now - lastNavMs > NAV_DEBOUNCE_MS)) {
    sel=(sel+1)%N;   changedByButtons=true;
    lastNavMs = now;
  }

  if (leftNow && !leftWasDown && (now - lastActionMs > ACTION_DEBOUNCE_MS)){
    auto& s=settings();
    if (sel==0 && s.brightness>0)      { applyBrightness(s.brightness>8? s.brightness-8:0); }
    else if (sel==1)                   { applyTheme(Theme::Dark); }
    else if (sel==2)                   { applyAccent((s.accentColor + ACCENT_PRESET_COUNT - 1) % ACCENT_PRESET_COUNT); }
    else if (sel==3)                   { applyNeoPixel(false); }
    else if (sel==4)                   { applyAutoScan(false); }
    else if (sel==5)                   { if (s.tftInvertColors) { applyInvert(false); drawAll(); } }
    changedByButtons=true;
    lastActionMs = now;
  }
  if ((rightNow && !rightWasDown) && (now - lastActionMs > ACTION_DEBOUNCE_MS)){
    auto& s=settings();
    if (sel==0 && s.brightness<255)    { applyBrightness(s.brightness+8); }
    else if (sel==1)                   { applyTheme(Theme::Light); }
    else if (sel==2)                   { applyAccent((s.accentColor + 1) % ACCENT_PRESET_COUNT); }
    else if (sel==3)                   { applyNeoPixel(true); }
    else if (sel==4)                   { applyAutoScan(true); }
    else if (sel==5)                   { if (!s.tftInvertColors) { applyInvert(true); drawAll(); } }
    changedByButtons=true;
    lastActionMs = now;
  }

  upWasDown     = upNow;
  downWasDown   = downNow;
  leftWasDown   = leftNow;
  rightWasDown  = rightNow;
  selectWasDown = selectNow;

  handleTouch();

  if (changedByButtons || uiDirty) redrawIfChanged();

  delay(2);
}

}

/*──────────────────── ModulesUI ────────────────────
 * "I'll decide what's actually plugged in" screen.
 * Flip any module OFF here if that hardware isn't installed; its main-menu
 * entry will then show a quick "Not installed" notice instead of trying
 * to initialize/talk to the chip. Flip it back ON once you wire it up.
 */
namespace ModulesUI {

static const int SCREEN_W = 240;
static const int BAR_H    = 22;
static const int TITLE_Y  = BAR_H + 4;
static const int TITLE_H  = 16;
static const int ROW_H    = 24;
static const int GAP_Y    = 4;
static const int PAD_X    = 12;

static const char* kItems[] = {
  "2.4GHz (NRF24)",
  "SubGHz (CC1101)",
  "IR Remote",
  "RFID / NFC",
  "GPS",
  "Cat easter egg",
  "Invert colors",
  "Fun extras",
};
static const int N = 8;

static int  sel = 0;
static bool uiDirty = false;
static bool dirtySettings = false;

static inline int rowY(int i) { return TITLE_Y + TITLE_H + 6 + i * (ROW_H + GAP_Y); }
struct Rect { int x,y,w,h; };
static inline Rect makeRect(int x,int y,int w,int h){ return {x,y,w,h}; }
static Rect rowRect(int i) { return makeRect(PAD_X, rowY(i), SCREEN_W - PAD_X*2, ROW_H); }

static bool* fieldPtr(int i) {
  auto& s = settings();
  switch (i) {
    case 0: return &s.moduleNrf24Enabled;
    case 1: return &s.moduleCc1101Enabled;
    case 2: return &s.moduleIrEnabled;
    case 3: return &s.moduleRfidEnabled;
    case 4: return &s.moduleGpsEnabled;
    case 5: return &s.catEasterEggEnabled;
    case 6: return &s.tftInvertColors;
    default: return &s.extrasEnabled;
  }
}

static Rect rSwitchTrack(int row){
  Rect r = rowRect(row);
  const int w = 34, h = 14;
  int x = r.x + r.w - w - 10;
  int y = r.y + (r.h - h) / 2;
  return makeRect(x, y, w, h);
}
static Rect rSwitchKnob(bool on, int row) {
  Rect tr = rSwitchTrack(row);
  int d = tr.h - 4;
  int x = on ? (tr.x + tr.w - d - 2) : (tr.x + 2);
  int y = tr.y + (tr.h - d) / 2;
  return makeRect(x, y, d, d);
}

static void drawRow(int i, bool selected) {
  Rect r = rowRect(i);
  bool on = *fieldPtr(i);

  tft.fillRect(0, r.y, SCREEN_W, r.h, UI_BG);
  if (selected) tft.fillRect(0, r.y, 3, r.h, UI.accent);

  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI_BG);
  tft.setCursor(r.x, r.y + (r.h/2 - 6));
  tft.print(kItems[i]);

  Rect tr = rSwitchTrack(i);
  tft.fillRoundRect(tr.x, tr.y, tr.w, tr.h, tr.h/2, UI_BG);
  tft.drawRoundRect(tr.x, tr.y, tr.w, tr.h, tr.h/2, UI_LINE);
  if (on) tft.fillRoundRect(tr.x+1, tr.y+1, tr.w-2, tr.h-2, tr.h/2, UI_ICON);

  Rect kb = rSwitchKnob(on, i);
  tft.fillCircle(kb.x+kb.w/2, kb.y+kb.h/2, kb.w/2, UI_FG);
  tft.drawCircle(kb.x+kb.w/2, kb.y+kb.h/2, kb.w/2, on ? UI.accent : UI_FG);

  tft.setCursor(tr.x - 28, tr.y + 1);
  tft.print(on ? "ON " : "OFF");

  tft.drawLine(PAD_X, r.y + r.h - 1, SCREEN_W - PAD_X, r.y + r.h - 1, UI_LINE);
}

static Rect backRect(){
  int h = tft.height();
  int bwTotal = SCREEN_W - PAD_X*2;
  int bh = 24, bx = PAD_X, by = h - bh - 8, gap = 8;
  int bw = (bwTotal - gap) / 2;
  return makeRect(bx, by, bw, bh);
}
static Rect saveRect(){
  Rect b = backRect();
  const int gap = 8;
  return makeRect(b.x + b.w + gap, b.y, b.w, b.h);
}
static void drawFooter(){
  Rect b = backRect();
  Rect s = saveRect();
  tft.fillRect(PAD_X-2, b.y-2, SCREEN_W-(PAD_X*2)+4, b.h+4, UI.bg);
  FeatureUI::drawButtonRect(b.x, b.y, b.w, b.h, "Back", FeatureUI::ButtonStyle::Secondary);
  FeatureUI::drawButtonRect(s.x, s.y, s.w, s.h, "Save", FeatureUI::ButtonStyle::Primary);
}
static bool touchInRect(const Rect& r, int x, int y) {
  return (x>=r.x && x<=r.x+r.w && y>=r.y && y<=r.y+r.h);
}

static void drawAll() {
  tft.fillScreen(UI_BG);
  drawStatusBar(currentBatteryVoltage, true);
  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, UI.bg);
  tft.setCursor(PAD_X, TITLE_Y);
  tft.print("Modules & Extras");
  for (int i = 0; i < N; i++) drawRow(i, sel==i);
  drawFooter();
  uiDirty = false;
}

static void toggle(int i, bool on) {
  bool* f = fieldPtr(i);
  if (*f == on) return;
  *f = on;
  dirtySettings = true;
  if (i == 6) tft.invertDisplay(on); // live-apply "Invert colors"
  drawRow(i, sel==i);
}

static void handleTouch() {
  int tx, ty;
  if (!readTouchXY(tx, ty)) return;

  Rect br = backRect(), sr = saveRect();
  if (touchInRect(br, tx, ty)) { feature_exit_requested = true; return; }
  if (touchInRect(sr, tx, ty)) {
    bool ok = dirtySettings ? settingsSave() : true;
    showNotification("Modules", ok ? "Saved." : "SD save failed.");
    delay(350);
    hideNotification();
    drawAll();
    return;
  }
  static uint32_t lastToggleMs = 0;
  uint32_t now = millis();
  for (int i = 0; i < N; i++) {
    Rect tr = rSwitchTrack(i);
    if (tx >= tr.x-8 && tx <= tr.x+tr.w+8 && ty >= tr.y-12 && ty <= tr.y+tr.h+12) {
      if (now - lastToggleMs > 180) {
        toggle(i, !(*fieldPtr(i)));
        lastToggleMs = now;
      }
      sel = i;
    }
  }
}

void setup() {
  sel = 0; uiDirty = false; dirtySettings = false;
  drawAll();
}

void loop() {
  static bool upWasDown=false, downWasDown=false, leftWasDown=false, rightWasDown=false, selWasDown=false;
  static uint32_t lastNavMs = 0;
  const uint32_t NAV_DEBOUNCE_MS = 140;
  uint32_t now = millis();

  bool upNow = isButtonPressed(BTN_UP);
  bool downNow = isButtonPressed(BTN_DOWN);
  bool leftNow = isButtonPressed(BTN_LEFT);
  bool rightNow = isButtonPressed(BTN_RIGHT);
  bool selNow = isButtonPressed(BTN_SELECT);

  if (selNow && !selWasDown) { feature_exit_requested = true; return; }

  if (upNow && !upWasDown && (now-lastNavMs>NAV_DEBOUNCE_MS)) { sel=(sel+N-1)%N; lastNavMs=now; drawAll(); }
  if (downNow && !downWasDown && (now-lastNavMs>NAV_DEBOUNCE_MS)) { sel=(sel+1)%N; lastNavMs=now; drawAll(); }
  if (leftNow && !leftWasDown && (now-lastNavMs>NAV_DEBOUNCE_MS)) { toggle(sel,false); lastNavMs=now; }
  if (rightNow && !rightWasDown && (now-lastNavMs>NAV_DEBOUNCE_MS)) { toggle(sel,true); lastNavMs=now; }

  upWasDown=upNow; downWasDown=downNow; leftWasDown=leftNow; rightWasDown=rightNow; selWasDown=selNow;

  handleTouch();
  delay(2);
}

} // namespace ModulesUI

/*──────────────────── Feature wait spinner ─────────────────────────
 * Lightweight "please wait" splash for inside features.
 * Uses UI_* palette so it looks correct on every theme and on CYD's
 * inverted panel — no skull bitmaps, no raw color constants.
 */
void showWaitSpinner(const char* line1, const char* line2) {
  tft.fillScreen(UI_BG);
  drawStatusBar(currentBatteryVoltage, true);
  const int cx = tft.width() / 2;
  const int cy = tft.height() / 2 - 10;

  // Animated dots — simple 3-dot spinner drawn once
  tft.setTextFont(2);
  tft.setTextColor(UI_ICON, UI_BG);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(line1, cx, cy - 12);

  tft.setTextColor(UI_TEXT, UI_BG);
  tft.drawString(line2, cx, cy + 12);

  // A subtle pulsing ring instead of the skull
  tft.drawCircle(cx, cy + 42, 14, UI.accent);
  tft.drawCircle(cx, cy + 42, 11, UI_LINE);
  // dots on ring to look like a spinner
  for (int i = 0; i < 8; i++) {
    float angle = i * (PI / 4.0f);
    int px = cx + (int)(12 * cosf(angle));
    int py = cy + 42 + (int)(12 * sinf(angle));
    uint16_t col = (i < 3) ? UI.accent : UI_LINE;
    tft.drawPixel(px, py, col);
    tft.drawPixel(px+1, py, col);
  }
  tft.setTextDatum(TL_DATUM);
}

/*──────────────────── Cyber-cat idle easter egg ────────────────────
 * Flipper-dolphin-style screensaver: after some idle time on the main
 * menu, a little cat runs along the bottom of the screen with a speech
 * bubble cracking pentest jokes. Any button/touch ends it immediately.
 */
static const char* kCatJokes[] = {
  "brb, hacking a Tesla",
  "sniffing packets, not glue",
  "deauth first, apologize later",
  "your wifi password is... loading",
  "meow-in-the-middle attack",
  "pwning IoT lightbulbs since 2024",
  "ctrl+alt+defeat",
  "not a cat, a cyber-cat(tm)",
  "01001000 01101001",
  "brute-forcing your garage door",
  "flipper who? i'm the original",
  "RFID? more like RF-i-did",
  "this cat has root access",
  "beep boop, scanning for victims (jk)",
  "subghz jam session, literally",
  "9 lives, 0 CVEs patched",
  "i don't chase mice, i chase packets",
  "your neighbor's wifi is my wifi now",
  "knock knock, it's your smart doorbell",
  "cat.exe has stopped responding (good)",
  "sudo give me treats",
  "scanning... found 1 unlocked car",
  "i speak fluent SPI and sarcasm",
  "firmware so old it has whiskers too",
  "napping between exploits",
  "this cat judges your password policy",
  "404: ethics not found (jk, be nice)",
  "bluetooth? more like blue-tooth-paste",
  "chasing the laser pointer... i mean RSSI",
  "mrrp = packet captured",
  "all your base are belong to cat",
  "running on 3.3V and spite",
  "i've seen things... unencrypted things",
  "my favorite protocol is pspspsps",
  "jamming to my own static",
};
static const int kCatJokeCount = sizeof(kCatJokes)/sizeof(kCatJokes[0]);

static bool anyInputActive() {
  return isButtonPressed(BTN_UP) || isButtonPressed(BTN_DOWN) ||
         isButtonPressed(BTN_LEFT) || isButtonPressed(BTN_RIGHT) ||
         isButtonPressed(BTN_SELECT) || isTouchDownDismiss();
}

static void drawCatFrame(int x, int y, bool stepUp) {
  uint16_t body = TFT_WHITE;
  uint16_t ears  = UI.accent;
  // body
  tft.fillRoundRect(x, y, 22, 12, 4, body);
  // head
  tft.fillCircle(x + 4, y - 2, 6, body);
  // ears
  tft.fillTriangle(x-1, y-6, x+2, y-12, x+5, y-6, ears);
  tft.fillTriangle(x+4, y-6, x+7, y-12, x+10, y-6, ears);
  // eye
  tft.fillCircle(x + 2, y - 2, 1, TFT_BLACK);
  // tail
  if (stepUp) tft.drawLine(x+21, y+2, x+27, y-4, body);
  else        tft.drawLine(x+21, y+4, x+27, y+8, body);
  // legs (simple alternating step)
  int legY = y + 12;
  if (stepUp) {
    tft.drawLine(x+4,  legY, x+2,  legY+4, body);
    tft.drawLine(x+16, legY, x+18, legY+4, body);
  } else {
    tft.drawLine(x+4,  legY, x+6,  legY+4, body);
    tft.drawLine(x+16, legY, x+14, legY+4, body);
  }
}

static void catScreensaverRun() {
  tft.fillScreen(TFT_BLACK);
  const int W = tft.width();
  const int H = tft.height();
  const int catY = H - 22;

  int jokeIdx = random(kCatJokeCount);
  int x = -24;
  bool stepUp = false;
  uint32_t lastStep = millis();
  uint32_t lastJoke  = millis();
  int lastBubbleW = 0;

  while (!anyInputActive()) {
    uint32_t now = millis();

    if (now - lastStep > 70) {
      // erase previous cat + bubble area, then redraw at new position
      tft.fillRect(0, catY - 16, W, 24, TFT_BLACK);
      if (lastBubbleW > 0) tft.fillRect(0, catY - 40, W, 22, TFT_BLACK);

      drawCatFrame(x, catY, stepUp);
      stepUp = !stepUp;

      const char* joke = kCatJokes[jokeIdx];
      tft.setTextFont(2);
      tft.setTextColor(TFT_GREEN, TFT_BLACK);
      int tw = (int)tft.textWidth(joke);
      int bx = constrain(x - 10, 2, max(2, W - tw - 14));
      tft.setCursor(bx, catY - 36);
      tft.print(joke);
      lastBubbleW = tw;

      x += 3;
      if (x > W + 10) {
        x = -24;
        if (now - lastJoke > 1500) {
          jokeIdx = random(kCatJokeCount);
          lastJoke = now;
        }
      }
      lastStep = now;
    }
    delay(10);
  }
}

// Second idle-screensaver flavor: green hex/binary "matrix rain" with an
// occasional flickering status line. Picked at random alongside the cat.
static void matrixRainScreensaverRun() {
  tft.fillScreen(TFT_BLACK);
  const int W = tft.width();
  const int H = tft.height();
  const int colW = 12;
  const int cols = W / colW;
  static int dropY[40];
  for (int c = 0; c < cols && c < 40; c++) dropY[c] = random(-H, 0);

  const char* statusLines[] = {
    "ACCESS GRANTED", "BRUTE FORCING...", "ROOT@CYD:~#",
    "DECRYPTING...", "0xDEADBEEF", "PWNED"
  };
  uint32_t lastFlicker = millis();
  int statusIdx = 0;

  tft.setTextFont(1);
  while (!anyInputActive()) {
    for (int c = 0; c < cols && c < 40; c++) {
      char ch = (random(0, 2) == 0) ? ('0' + random(0, 2)) : (char)('A' + random(0, 16));
      tft.setTextColor(TFT_DARKGREEN, TFT_BLACK);
      tft.drawChar(c * colW, dropY[c] - 10, ch, TFT_DARKGREEN, TFT_BLACK, 1);
      tft.setTextColor(TFT_GREEN, TFT_BLACK);
      tft.drawChar(c * colW, dropY[c], ch, TFT_GREEN, TFT_BLACK, 1);
      dropY[c] += 8;
      if (dropY[c] > H + 10) dropY[c] = random(-40, 0);
    }
    if (millis() - lastFlicker > 1800) {
      tft.fillRect(0, H/2 - 8, W, 16, TFT_BLACK);
      tft.setTextFont(2);
      tft.setTextColor(TFT_GREEN, TFT_BLACK);
      statusIdx = random(0, (int)(sizeof(statusLines)/sizeof(statusLines[0])));
      const char* s = statusLines[statusIdx];
      int tw = (int)tft.textWidth(s);
      tft.setCursor((W - tw)/2, H/2 - 7);
      tft.print(s);
      tft.setTextFont(1);
      lastFlicker = millis();
    }
    delay(40);
  }
}

// ── Persistent cat strip on the main menu ──────────────────────────────────
// Lives in the bottom 32 px of the screen (y=288..320 on CYD 240×320).
// Drawn incrementally every ~60 ms so it doesn't block anything.
// Called from loop() when on the main menu; also called from displayMenu()
// to paint the initial frame after a full-screen redraw.

static int      s_catX       = -24;
static bool     s_catStep    = false;
static uint32_t s_catLastMs  = 0;
static int      s_catJokeIdx = 0;
static bool     s_catDir     = true;   // true = moving right

static const int CAT_STRIP_Y  = 288;   // must match Y_START + 3*Y_SPACING + card_h
static const int CAT_STRIP_H  = 32;
static const int CAT_SPRITE_H = 18;    // visible sprite area

static void drawCatStrip(int x, bool stepUp, const char* joke) {
  const int W  = tft.width();
  const int sy = CAT_STRIP_Y;

  // Background
  tft.fillRect(0, sy, W, CAT_STRIP_H, UI_BG);

  // Divider line at top of strip
  tft.drawFastHLine(0, sy, W, UI_LINE);

  // Joke text — centred
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(UI_ICON, UI_BG);
  int tw = (int)tft.textWidth(joke);
  if (tw < W - 32) {
    tft.setCursor((W - tw) / 2, sy + 2);
    tft.print(joke);
  } else {
    // Truncate to fit
    tft.setCursor(4, sy + 2);
    tft.print(joke);
  }

  // Mini cat sprite (uses existing drawCatFrame helper, clipped to strip)
  int catY = sy + (CAT_STRIP_H - CAT_SPRITE_H) / 2 + 2;
  int cx = constrain(x, -24, W + 10);
  drawCatFrame(cx, catY, stepUp);
}

// Called from loop() every frame while on the main menu.
// Returns true the first time it draws (so callers know the strip is live).
bool updateMainMenuCatStrip() {
  if (!settings().catEasterEggEnabled) return false;

  uint32_t now = millis();
  if (now - s_catLastMs < 55) return false;  // ~18 fps
  s_catLastMs = now;

  s_catX += s_catDir ? 4 : -4;

  if (s_catDir && s_catX > tft.width() + 10) {
    s_catDir = false;
    s_catJokeIdx = (s_catJokeIdx + 1) % kCatJokeCount;
  } else if (!s_catDir && s_catX < -24) {
    s_catDir = true;
    s_catJokeIdx = (s_catJokeIdx + 1) % kCatJokeCount;
  }

  s_catStep = !s_catStep;
  drawCatStrip(s_catX, s_catStep, kCatJokes[s_catJokeIdx]);
  return true;
}

// Reset strip state (call after displayMenu() redraws so position stays valid)
void resetMainMenuCatStrip() {
  s_catX      = -24;
  s_catDir    = true;
  s_catStep   = false;
  s_catLastMs = 0;
}

// ── Old full-screen idle screensaver (kept for reference; not called from loop) ──
bool catEasterEggTick() {
  // Replaced by updateMainMenuCatStrip() for the persistent-strip behaviour.
  // Kept so callers that might reference the symbol don't break.
  return false;
}

/*──────────────────── ArcadeUI: "Catch the Packet" ────────────────────
 * Tiny DIV-flavored reflex mini-game. LEFT/RIGHT (or tap left/right half
 * of the screen) move the paddle; catch falling packets, 3 misses and
 * it's game over. BTN_SELECT exits any time. Purely cosmetic — no radio,
 * no real traffic, just a bit of fun hidden in Tools.
 */
namespace ArcadeUI {

static int paddleX;
static int score;
static int misses;
static int pktX, pktY;
static int pktSpeed;
static uint32_t lastTick;
static bool gameOver;

static const int PADDLE_W = 36, PADDLE_H = 6;
static const int PKT_SZ = 8;

static void resetPacket() {
  pktX = random(4, tft.width() - PKT_SZ - 4);
  pktY = 24;
  pktSpeed = 2 + min(misses + score / 5, 4);
}

static void drawFrame() {
  int W = tft.width(), H = tft.height();
  tft.fillScreen(TFT_BLACK);
  tft.setTextFont(2);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.setCursor(4, 4);
  tft.print("Score: "); tft.print(score);
  tft.setCursor(W - 70, 4);
  tft.setTextColor(TFT_RED, TFT_BLACK);
  tft.print("Miss: "); tft.print(misses); tft.print("/3");

  tft.fillRect(pktX, pktY, PKT_SZ, PKT_SZ, TFT_YELLOW);
  tft.drawRect(pktX, pktY, PKT_SZ, PKT_SZ, TFT_BLACK);

  tft.fillRect(paddleX, H - 16, PADDLE_W, PADDLE_H, TFT_CYAN);

  if (gameOver) {
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    const char* msg = "GAME OVER - SELECT to exit";
    int tw = (int)tft.textWidth(msg);
    tft.setCursor((W - tw)/2, H/2);
    tft.print(msg);
  }
}

void setup() {
  int W = tft.width();
  paddleX = (W - PADDLE_W) / 2;
  score = 0; misses = 0; gameOver = false;
  resetPacket();
  lastTick = millis();
  drawFrame();
}

void loop() {
  if (isButtonPressed(BTN_SELECT)) { feature_exit_requested = true; return; }

  if (gameOver) { delay(20); return; }

  int W = tft.width(), H = tft.height();
  bool moved = false;
  if (isButtonPressed(BTN_LEFT))  { paddleX -= 8; moved = true; }
  if (isButtonPressed(BTN_RIGHT)) { paddleX += 8; moved = true; }
  int tx, ty;
  if (readTouchXY(tx, ty)) {
    if (tx < W/2) { paddleX -= 10; } else { paddleX += 10; }
    moved = true;
  }
  paddleX = constrain(paddleX, 0, W - PADDLE_W);

  uint32_t now = millis();
  if (now - lastTick > 30) {
    pktY += pktSpeed;
    lastTick = now;

    bool caught = (pktY + PKT_SZ >= H - 16) && (pktX + PKT_SZ >= paddleX) && (pktX <= paddleX + PADDLE_W);
    if (caught) {
      score++;
      resetPacket();
    } else if (pktY > H) {
      misses++;
      if (misses >= 3) { gameOver = true; }
      else resetPacket();
    }
    drawFrame();
  } else if (moved) {
    drawFrame();
  }
  delay(5);
}

} // namespace ArcadeUI

namespace SdFileManager {

using FeatureUI::Button;
using FeatureUI::ButtonStyle;

static constexpr uint16_t COL_BG   = FEATURE_BG;
static constexpr int STATUS_BAR_H = 20;
static constexpr int HEADER_H = 54;

static String ellipsize(const String& s, int maxW, uint8_t font) {
  if (tft.textWidth(s, font) <= maxW) return s;
  String out = s;
  while (out.length() > 0 && tft.textWidth(out + "...", font) > maxW) {
    out.remove(out.length() - 1);
  }
  return out + "...";
}

struct Entry {
  String name;
  String path;
  bool isDir = false;
  uint32_t size = 0;
  bool isUp = false; // synthetic ".."
};

enum class Page : uint8_t { Browser, Info, ConfirmDelete };

static Page page = Page::Browser;
static std::vector<Entry> entries;
static String cwd = "/";
static int sel = 0;
static int listStart = 0;
static bool uiDirty = true;
static bool touchActive = false;
static bool touchDragging = false;
static int touchStartX = 0;
static int touchStartY = 0;
static int touchLastY = 0;
static int scrollAccumY = 0;

static Button browserBtns[4];
static Button infoBtns[2];
static Button confirmBtns[2];

static String lastErr;

static int sdFmContentBottom() {
  return featureHasTouchNavBar() ? (int)touchNavContentBottomY()
                                 : (int)(tft.height() - FeatureUI::FOOTER_H - 2);
}

static void sdFmRestoreNavChrome() {
  if (!featureHasTouchNavBar()) {
    return;
  }
  invalidateTouchButtonCue();
  maintainTouchNavBar();
}

static char s_sdFmNavCache[5][12] = {{0}};

static void sdFmResetNavLabelCache() {
  for (int i = 0; i < 5; ++i) {
    s_sdFmNavCache[i][0] = '\0';
  }
}

static void sdFmApplyNavLabels(const char* left, const char* down, const char* center,
                               const char* up, const char* right) {
  if (!featureHasTouchNavBar()) {
    return;
  }
  const char* src[5] = {left, down, center, up, right};
  bool same = true;
  for (int i = 0; i < 5; ++i) {
    const char* s = (src[i] && src[i][0]) ? src[i] : "";
    if (strcmp(s_sdFmNavCache[i], s) != 0) {
      same = false;
      break;
    }
  }
  if (same) {
    return;
  }
  for (int i = 0; i < 5; ++i) {
    const char* s = (src[i] && src[i][0]) ? src[i] : "";
    strncpy(s_sdFmNavCache[i], s, sizeof(s_sdFmNavCache[i]) - 1);
    s_sdFmNavCache[i][sizeof(s_sdFmNavCache[i]) - 1] = '\0';
  }
  setTouchNavLabels(left, down, center, up, right);
  redrawTouchButtonBar();
}

static void sdFmUpdateBrowserNavLabels() {
  sdFmApplyNavLabels("Exit", "Next", "Refresh", "Prev", "Open");
}

static void sdFmUpdateInfoNavLabels() {
  sdFmApplyNavLabels("Back", nullptr, "Delete", nullptr, nullptr);
}

static void sdFmUpdateConfirmNavLabels() {
  sdFmApplyNavLabels("Cancel", nullptr, "Delete", nullptr, nullptr);
}

static void clampSel();
static bool reloadDir(const String& path, String* errOut);
static void resetListDrawCache();
static void drawBrowserPage(bool full = true);
static void drawConfirmDeletePage();
static void openSelected();
static bool deleteSelected(String* errOut);

static void sdFmHandleNavButtons() {
  if (!featureHasTouchNavBar()) {
    return;
  }
  if (page == Page::Browser) {
    if (isTouchNavButtonPressedEdge(BTN_LEFT)) {
      feature_exit_requested = true;
      return;
    }
    if (isTouchNavButtonPressedEdge(BTN_UP) && !entries.empty()) {
      sel--;
      clampSel();
      drawBrowserPage(false);
      return;
    }
    if (isTouchNavButtonPressedEdge(BTN_DOWN) && !entries.empty()) {
      sel++;
      clampSel();
      drawBrowserPage(false);
      return;
    }
    if (isTouchNavButtonPressedEdge(BTN_RIGHT)) {
      openSelected();
      return;
    }
    if (isTouchNavButtonPressedEdge(BTN_SELECT)) {
      reloadDir(cwd, nullptr);
      drawBrowserPage(true);
    }
  } else if (page == Page::Info) {
    if (isTouchNavButtonPressedEdge(BTN_LEFT)) {
      drawBrowserPage();
      return;
    }
    if (isTouchNavButtonPressedEdge(BTN_SELECT)) {
      drawConfirmDeletePage();
    }
  } else if (page == Page::ConfirmDelete) {
    if (isTouchNavButtonPressedEdge(BTN_LEFT)) {
      drawBrowserPage();
      return;
    }
    if (isTouchNavButtonPressedEdge(BTN_SELECT)) {
      String err;
      const bool ok = deleteSelected(&err);
      if (!ok) {
        showNotification("Delete", err.c_str());
        delay(500);
      }
      reloadDir(cwd, nullptr);
      drawBrowserPage();
    }
  }
}

static File sdOpenCompat(const String& path) {
  File f = SD.open(path.c_str());
  if (f) return f;
  if (path.length() > 1 && path[0] == '/') {
    f = SD.open(path.substring(1).c_str());
  }
  return f;
}

static bool sdRemoveCompat(const String& path) {
  if (SD.remove(path.c_str())) return true;
  if (path.length() > 1 && path[0] == '/') return SD.remove(path.substring(1).c_str());
  return false;
}

static bool sdRmdirCompat(const String& path) {
  if (SD.rmdir(path.c_str())) return true;
  if (path.length() > 1 && path[0] == '/') return SD.rmdir(path.substring(1).c_str());
  return false;
}

static String normalizePath(const String& path) {
  if (path.length() == 0) return "/";
  String p = path;
  if (p[0] != '/') p = "/" + p;

  String out;
  out.reserve(p.length());
  bool lastSlash = false;
  for (size_t i = 0; i < p.length(); ++i) {
    char c = p[i];
    if (c == '/') {
      if (!lastSlash) out += c;
      lastSlash = true;
    } else {
      out += c;
      lastSlash = false;
    }
  }

  while (out.length() > 1 && out.endsWith("/")) {
    out.remove(out.length() - 1);
  }
  return out;
}

static void clampSel() {
  if (entries.empty()) { sel = 0; return; }
  if (sel < 0) sel = 0;
  if (sel >= (int)entries.size()) sel = (int)entries.size() - 1;
}

static void listLayout(int& top, int& bottom, int& rowH, int& maxVisible) {
  top = STATUS_BAR_H + HEADER_H + 6;
  bottom = sdFmContentBottom();
  rowH = 22;
  maxVisible = max(1, (bottom - top) / rowH);
}

static void clampListStart(int maxVisible) {
  int maxStart = max(0, (int)entries.size() - maxVisible);
  if (listStart < 0) listStart = 0;
  if (listStart > maxStart) listStart = maxStart;
}

static void ensureSelectionVisible(int maxVisible) {
  if (entries.empty()) { listStart = 0; return; }
  if (sel < listStart) listStart = sel;
  if (sel >= listStart + maxVisible) listStart = sel - maxVisible + 1;
  clampListStart(maxVisible);
}

static String parentPath(const String& p) {
  String np = normalizePath(p);
  if (np == "/") return "/";
  int slash = np.lastIndexOf('/');
  if (slash <= 0) return "/";
  return np.substring(0, slash);
}

static bool reloadDir(const String& path, String* errOut = nullptr) {
  entries.clear();
  lastErr = "";

  if (!isSDCardAvailable()) {
    if (errOut) *errOut = "SD not mounted";
    lastErr = "SD not mounted";
    return false;
  }

  String openPath = normalizePath(path);

  File dir = sdOpenCompat(openPath);
  if (!dir) {
    if (errOut) *errOut = "Open dir failed";
    lastErr = "Open dir failed";
    return false;
  }
  if (!dir.isDirectory()) {
    dir.close();
    if (errOut) *errOut = "Not a directory";
    lastErr = "Not a directory";
    return false;
  }

  cwd = openPath;

  if (cwd != "/") {
    Entry up;
    up.name = "..";
    up.path = parentPath(cwd);
    up.isDir = true;
    up.isUp = true;
    entries.push_back(up);
  }

  for (;;) {
    File f = dir.openNextFile();
    if (!f) break;

    Entry e;
    {
      String raw = String(f.name());
      while (raw.endsWith("/")) raw.remove(raw.length() - 1);
      int slash = raw.lastIndexOf('/');
      String base = (slash >= 0) ? raw.substring(slash + 1) : raw;
      while (base.startsWith("/")) base.remove(0, 1);
      while (base.endsWith("/")) base.remove(base.length() - 1);
      e.name = base.length() ? base : raw;
      while (e.name.startsWith("/")) e.name.remove(0, 1);
      while (e.name.endsWith("/")) e.name.remove(e.name.length() - 1);
      if (e.name.length() == 0) { f.close(); continue; }
    }
    e.isDir = f.isDirectory();
    e.size = e.isDir ? 0 : (uint32_t)f.size();
    if (cwd == "/") e.path = "/" + e.name;
    else e.path = cwd + "/" + e.name;
    e.path = normalizePath(e.path);

    entries.push_back(e);
    f.close();
    yield();
  }
  dir.close();

  // Sort, keeping ".." first when present.
  int start = (entries.size() && entries[0].isUp) ? 1 : 0;
  std::sort(entries.begin() + start, entries.end(), [](const Entry& a, const Entry& b) {
    if (a.isDir != b.isDir) return a.isDir > b.isDir;
    return a.name < b.name;
  });

  sel = 0;
  listStart = 0;
  uiDirty = true;
  resetListDrawCache();
  return true;
}

static void drawHeader(const char* title) {
  const int w = tft.width();
  const int y0 = STATUS_BAR_H;
  tft.fillRect(0, y0, w, HEADER_H, FEATURE_BG);

  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setTextColor(UI_ICON, FEATURE_BG);
  tft.setCursor(8, y0 + 4);
  tft.print(title);

  tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, FEATURE_BG);
  String pathLine = ellipsize(cwd, w - 16, 1);
  tft.setCursor(8, y0 + 24);
  tft.print(pathLine);

  String right = entries.empty()
    ? String("0/0")
    : String(sel + 1) + "/" + String((int)entries.size());
  String left = String("Items: ") + String((int)entries.size());
  int rightW = tft.textWidth(right, 1);
  tft.setCursor(8, y0 + 40);
  tft.print(left);
  tft.setCursor(w - 8 - rightW, y0 + 40);
  tft.print(right);

  tft.drawLine(0, y0 + HEADER_H, w, y0 + HEADER_H, UI_LINE);
}

static void drawHeaderSelCounter() {
  const int w = tft.width();
  const int y0 = STATUS_BAR_H;
  String right = entries.empty()
    ? String("0/0")
    : String(sel + 1) + "/" + String((int)entries.size());
  int rightW = tft.textWidth(right, 1);
  tft.fillRect(w - 8 - max(rightW, 40), y0 + 38, max(rightW, 40) + 4, 14, FEATURE_BG);
  tft.setTextFont(1);
  tft.setTextColor(UI_TEXT, FEATURE_BG);
  tft.setCursor(w - 8 - rightW, y0 + 40);
  tft.print(right);
}

static void drawListRow(int idx, int y, int rowH, bool selected) {
  const int x = 8;
  const int w = tft.width() - 16;
  uint16_t bg = selected ? UI_FG : FEATURE_BG;
  uint16_t fg = selected ? UI_ICON : UI_TEXT;

  tft.fillRect(x, y, w, rowH - 1, bg);
  tft.drawLine(x, y + rowH - 1, x + w, y + rowH - 1, UI_LINE);

  tft.setTextFont(1);
  tft.setTextColor(fg, bg);
  String label = entries[idx].name;
  if (entries[idx].isDir && !entries[idx].isUp) label = label + "/";
  label = ellipsize(label, w - 80, 1);
  tft.setCursor(x + 4, y + 6);
  tft.print(label);

  String right = entries[idx].isDir ? "DIR" : "";
  if (!entries[idx].isDir && !entries[idx].isUp) {
    char sbuf[16];
    uint32_t kb = (entries[idx].size + 1023) / 1024;
    snprintf(sbuf, sizeof(sbuf), "%lukB", (unsigned long)kb);
    right = sbuf;
  }
  if (right.length()) {
    int tw = tft.textWidth(right, 1);
    tft.setCursor(x + w - tw - 6, y + 6);
    tft.print(right);
  }
}

static void drawListScrollbar(int top, int bottom, int start, int maxVisible) {
  if ((int)entries.size() <= maxVisible) {
    return;
  }
  int scrollBarX = tft.width() - 6;
  int scrollBarHeight = bottom - top - 6;
  int scrollBarY = top + 3;
  int indicatorHeight = (maxVisible * scrollBarHeight) / (int)entries.size();
  if (indicatorHeight < 6) indicatorHeight = 6;
  int indicatorY = scrollBarY;
  indicatorY = scrollBarY + (start * (scrollBarHeight - indicatorHeight)) /
                            max(1, (int)entries.size() - maxVisible);
  tft.fillRect(scrollBarX, scrollBarY, 3, scrollBarHeight, UI_LINE);
  tft.fillRect(scrollBarX, indicatorY, 3, indicatorHeight, UI_ACCENT);
}

static int s_lastListSel = -1;
static int s_lastListStart = -1;

static void resetListDrawCache() {
  s_lastListSel = -1;
  s_lastListStart = -1;
}

static void drawList(bool full = true) {
  int top, bottom, rowH, maxVisible;
  listLayout(top, bottom, rowH, maxVisible);

  if (!isSDCardAvailable()) {
    tft.fillRect(0, top, tft.width(), bottom - top, COL_BG);
    tft.setTextFont(2);
    tft.setTextColor(UI_WARN, COL_BG);
    tft.drawCentreString("SD not mounted", tft.width() / 2, top + 30, 2);
    resetListDrawCache();
    return;
  }

  if (entries.empty()) {
    tft.fillRect(0, top, tft.width(), bottom - top, COL_BG);
    tft.setTextFont(2);
    tft.setTextColor(UI_TEXT, COL_BG);
    tft.drawCentreString("Empty folder", tft.width() / 2, top + 30, 2);
    resetListDrawCache();
    return;
  }

  clampSel();
  ensureSelectionVisible(maxVisible);

  int start = listStart;
  int end = min((int)entries.size(), start + maxVisible);

  const bool windowChanged = full || s_lastListSel < 0 || s_lastListStart != start;
  if (windowChanged) {
    tft.fillRect(0, top, tft.width(), bottom - top, COL_BG);
    for (int i = start; i < end; ++i) {
      int y = top + (i - start) * rowH;
      drawListRow(i, y, rowH, i == sel);
    }
    drawListScrollbar(top, bottom, start, maxVisible);
    drawHeaderSelCounter();
    s_lastListSel = sel;
    s_lastListStart = start;
    return;
  }

  if (s_lastListSel != sel) {
    drawHeaderSelCounter();
    const int oldSel = s_lastListSel;
    const int newSel = sel;
    if (oldSel >= start && oldSel < end) {
      drawListRow(oldSel, top + (oldSel - start) * rowH, rowH, false);
    }
    if (newSel >= start && newSel < end) {
      drawListRow(newSel, top + (newSel - start) * rowH, rowH, true);
    }
    s_lastListSel = sel;
  }
}

static void drawBrowserFooter() {
  if (featureHasTouchNavBar()) {
    sdFmUpdateBrowserNavLabels();
    return;
  }
  bool sdOk = isSDCardAvailable();
  bool hasSel = !entries.empty();
  bool selIsUp = false;
  if (hasSel) {
    clampSel();
    selIsUp = entries[sel].isUp;
  }

  FeatureUI::drawFooterBg();
  FeatureUI::layoutFooter4(
    browserBtns,
    "Exit",    ButtonStyle::Secondary,
    "Open",    ButtonStyle::Primary,
    "Delete",  ButtonStyle::Danger,
    "Refresh", ButtonStyle::Secondary,
    false,
    (!sdOk || !hasSel),
    (!sdOk || !hasSel || selIsUp),
    false
  );
  for (auto& b : browserBtns) FeatureUI::drawButton(b);
}

static void drawBrowserPage(bool full) {
  page = Page::Browser;
  if (full) {
    featureClearContent(COL_BG);
    currentBatteryVoltage = readBatteryVoltage();
    drawStatusBar(currentBatteryVoltage, true);
    drawHeader("SD File Manager");
    drawBrowserFooter();
    drawList(true);
    sdFmRestoreNavChrome();
    uiDirty = false;
    return;
  }

  drawList(false);
  uiDirty = false;
}

static void drawInfoPage() {
  page = Page::Info;
  featureClearContent(COL_BG);
  currentBatteryVoltage = readBatteryVoltage();
  drawStatusBar(currentBatteryVoltage, true);
  drawHeader("File info");

  if (featureHasTouchNavBar()) {
    sdFmUpdateInfoNavLabels();
  } else {
    FeatureUI::drawFooterBg();
    FeatureUI::layoutFooter2(
      infoBtns,
      "Back",   ButtonStyle::Secondary,
      "Delete", ButtonStyle::Danger,
      false, (entries.empty() || !isSDCardAvailable())
    );
    for (auto& b : infoBtns) FeatureUI::drawButton(b);
  }

  const int top = STATUS_BAR_H + HEADER_H + 6;
  const int bottom = sdFmContentBottom();
  tft.fillRect(0, top, tft.width(), bottom - top, COL_BG);

  if (entries.empty()) {
    tft.setTextFont(2);
    tft.setTextColor(UI_TEXT, COL_BG);
    tft.drawCentreString("No selection", tft.width()/2, top + 24, 2);
    uiDirty = false;
    return;
  }

  clampSel();
  const Entry& e = entries[sel];

  tft.setTextFont(2);
  tft.setTextColor(UI_TEXT, COL_BG);
  tft.setCursor(8, top + 10);
  tft.print("Name:");
  tft.setCursor(70, top + 10);
  tft.print(e.name);

  tft.setCursor(8, top + 34);
  tft.print("Type:");
  tft.setCursor(70, top + 34);
  tft.print(e.isDir ? "Folder" : "File");

  if (!e.isDir) {
    tft.setCursor(8, top + 58);
    tft.print("Size:");
    tft.setCursor(70, top + 58);
    tft.print(String(e.size) + " B");
  }

  tft.setTextFont(1);
  tft.setCursor(8, top + 88);
  tft.print("Path:");
  tft.setCursor(8, top + 102);
  tft.print(e.path);

  sdFmRestoreNavChrome();
  uiDirty = false;
}

static void drawConfirmDeletePage() {
  page = Page::ConfirmDelete;
  featureClearContent(COL_BG);
  currentBatteryVoltage = readBatteryVoltage();
  drawStatusBar(currentBatteryVoltage, true);
  drawHeader("Confirm delete");

  if (featureHasTouchNavBar()) {
    sdFmUpdateConfirmNavLabels();
  } else {
    FeatureUI::drawFooterBg();
    FeatureUI::layoutFooter2(
      confirmBtns,
      "Cancel", ButtonStyle::Secondary,
      "Delete", ButtonStyle::Danger,
      false, false
    );
    for (auto& b : confirmBtns) FeatureUI::drawButton(b);
  }

  const int top = STATUS_BAR_H + HEADER_H + 6;
  const int bottom = sdFmContentBottom();
  tft.fillRect(0, top, tft.width(), bottom - top, COL_BG);

  tft.setTextFont(2);
  tft.setTextColor(UI_WARN, COL_BG);
  tft.drawCentreString("Delete selected item?", tft.width()/2, top + 18, 2);

  if (!entries.empty()) {
    const Entry& e = entries[sel];
    tft.setTextFont(1);
    tft.setTextColor(UI_TEXT, COL_BG);
    tft.drawCentreString(e.name.c_str(), tft.width()/2, top + 48, 1);
  }

  sdFmRestoreNavChrome();
  uiDirty = false;
}

static bool deleteSelected(String* errOut = nullptr) {
  if (entries.empty()) { if (errOut) *errOut = "Nothing selected"; return false; }
  clampSel();
  const Entry e = entries[sel];
  if (e.isUp) { if (errOut) *errOut = "Cannot delete .."; return false; }

  if (!isSDCardAvailable()) { if (errOut) *errOut = "SD not mounted"; return false; }

  bool ok = false;
  if (e.isDir) {
    // ESP32 FS supports rmdir. If directory is not empty it will fail.
    ok = sdRmdirCompat(e.path);
  } else {
    ok = sdRemoveCompat(e.path);
  }
  if (!ok) {
    if (errOut) *errOut = "Delete failed";
    return false;
  }
  return true;
}

static void openSelected() {
  if (entries.empty()) return;
  clampSel();
  const Entry& e = entries[sel];

  if (e.isDir) {
    String err;
    if (!reloadDir(normalizePath(e.path), &err)) {
      drawBrowserPage();
      String msg = err.length() ? err : "Failed";
      msg += "\n";
      msg += e.path;
      showNotification("Open", msg.c_str());
      delay(600);
      return;
    }
    drawBrowserPage();
    return;
  }
  drawInfoPage();
}

static bool hitListRow(int x, int y, int& outIdx) {
  int top, bottom, rowH, maxVisible;
  listLayout(top, bottom, rowH, maxVisible);
  if (y < top || y >= bottom) return false;

  ensureSelectionVisible(maxVisible);
  int start = listStart;
  int end = min((int)entries.size(), start + maxVisible);

  int row = (y - top) / rowH;
  int idx = start + row;
  if (idx < start || idx >= end) return false;
  outIdx = idx;
  return true;
}

static void handleTap(int x, int y) {
  if (page == Page::Browser) {
    int idx = -1;
    if (hitListRow(x, y, idx)) {
      if (idx != sel) {
        sel = idx;
        clampSel();
        drawBrowserPage(false);
      } else {
        openSelected();
      }
      delay(140);
      return;
    }

    int f = -1;
    if (!featureHasTouchNavBar()) {
      f = FeatureUI::hit(browserBtns, 4, x, y);
    }
    if (f >= 0) {
      FeatureUI::drawButton(browserBtns[f], true);
      delay(90);
      FeatureUI::drawButton(browserBtns[f], false);
      delay(90);

      if (f == 0) { feature_exit_requested = true; return; }          // Exit
      if (f == 1) { openSelected(); delay(120); return; }             // Open
      if (f == 2) {                                                   // Delete
        if (!entries.empty() && isSDCardAvailable() && !entries[sel].isUp) {
          drawConfirmDeletePage();
        }
        delay(120);
        return;
      }
      if (f == 3) { reloadDir(cwd, nullptr); drawBrowserPage(true); delay(120); return; } // Refresh
    }
  }
  else if (page == Page::Info) {
    int f = -1;
    if (!featureHasTouchNavBar()) {
      f = FeatureUI::hit(infoBtns, 2, x, y);
    }
    if (f >= 0) {
      FeatureUI::drawButton(infoBtns[f], true);
      delay(90);
      FeatureUI::drawButton(infoBtns[f], false);
      delay(90);

      if (f == 0) { drawBrowserPage(); delay(120); return; }         // Back
      if (f == 1) { drawConfirmDeletePage(); delay(120); return; }   // Delete
    }
  }
  else if (page == Page::ConfirmDelete) {
    int f = -1;
    if (!featureHasTouchNavBar()) {
      f = FeatureUI::hit(confirmBtns, 2, x, y);
    }
    if (f >= 0) {
      FeatureUI::drawButton(confirmBtns[f], true);
      delay(90);
      FeatureUI::drawButton(confirmBtns[f], false);
      delay(90);

      if (f == 0) {                                                  // Cancel
        drawBrowserPage();
        delay(120);
        return;
      }
      if (f == 1) {                                                  // Delete
        String err;
        bool ok = deleteSelected(&err);
        if (!ok) {
          showNotification("Delete", err.c_str());
          delay(500);
        }
        reloadDir(cwd, nullptr);
        drawBrowserPage();
        delay(120);
        return;
      }
    }
  }
}

void setup() {
  sdRetryMount();
  sdFmResetNavLabelCache();
  page = Page::Browser;
  cwd = "/";
  sel = 0;
  uiDirty = true;
  reloadDir("/", nullptr);
  currentBatteryVoltage = readBatteryVoltage();
  drawStatusBar(currentBatteryVoltage, true);
  drawBrowserPage();
}

void loop() {
  updateStatusBar();
  if (featureHasTouchNavBar()) {
    maintainTouchNavBar();
  }
  sdFmHandleNavButtons();
  if (feature_exit_requested) {
    return;
  }
  if (uiDirty) {
    switch (page) {
      case Page::Browser:        drawBrowserPage(true); break;
      case Page::Info:           drawInfoPage(); break;
      case Page::ConfirmDelete:  drawConfirmDeletePage(); break;
    }
  }

  // Physical navigation (kept for devices without touch nav bar).
  if (!featureHasTouchNavBar() && isButtonPressed(BTN_UP)) {
    if (page == Page::Browser && !entries.empty()) { sel--; clampSel(); drawBrowserPage(false); }
    delay(160);
    return;
  }
  if (!featureHasTouchNavBar() && isButtonPressed(BTN_DOWN)) {
    if (page == Page::Browser && !entries.empty()) { sel++; clampSel(); drawBrowserPage(false); }
    delay(160);
    return;
  }

  int x, y;
  bool touched = readTouchXY(x, y);
  if (!touched) {
    if (touchActive && !touchDragging) {
      handleTap(touchStartX, touchStartY);
    }
    touchActive = false;
    touchDragging = false;
    scrollAccumY = 0;
    return;
  }

  if (!touchActive) {
    touchActive = true;
    touchDragging = false;
    touchStartX = x;
    touchStartY = y;
    touchLastY = y;
    scrollAccumY = 0;
    return;
  }

  if (page == Page::Browser) {
    int top, bottom, rowH, maxVisible;
    listLayout(top, bottom, rowH, maxVisible);
    bool canScroll = (touchStartY >= top && touchStartY < bottom);

    int dy = y - touchLastY;
    touchLastY = y;

    if (!touchDragging && canScroll) {
      if (abs(y - touchStartY) > 8) {
        touchDragging = true;
      }
    }

    if (touchDragging && canScroll) {
      scrollAccumY += dy;
      int steps = scrollAccumY / rowH;
      if (steps != 0) {
        listStart -= steps;
        clampListStart(maxVisible);
        if (!entries.empty()) {
          if (sel < listStart) sel = listStart;
          if (sel >= listStart + maxVisible) sel = min((int)entries.size() - 1, listStart + maxVisible - 1);
        }
        drawBrowserPage(false);
        scrollAccumY -= steps * rowH;
      }
    }
  }

  return;
}

} // namespace SdFileManager

namespace TouchCalib {
static int stepIdx = 0;
static uint16_t xs[4], ys[4];
static const int pts[4][2] = { {20,20}, {TFT_WIDTH-20,20}, {TFT_WIDTH-20,TFT_HEIGHT-20}, {20,TFT_HEIGHT-20} };

static void drawTarget(int x,int y){
  tft.fillScreen(UI_BG);
  tft.drawCircle(x,y,10,UI_ICON);
  tft.drawLine(x-14,y, x+14,y, UI_ICON);
  tft.drawLine(x,y-14, x,y+14, UI_ICON);
  tft.setCursor(70, 8);
  tft.setTextColor(UI_TEXT, UI_BG);
  tft.print("Touch the target");
}

void setup(){
  stepIdx=0;
  drawTarget(pts[0][0], pts[0][1]);
}

void loop(){
  if (stepIdx>=4){
    uint16_t xMin = min(xs[0], xs[3]);
    uint16_t xMax = max(xs[1], xs[2]);
    uint16_t yMin = min(ys[0], ys[1]);
    uint16_t yMax = max(ys[2], ys[3]);
    auto& s = settings();
    s.touchXMin = xMin; s.touchXMax = xMax;
#if defined(BOARD_CYD)
    s.touchYMin = yMin; s.touchYMax = yMax;
#else
    s.touchYMin = yMax; s.touchYMax = yMin;
#endif

    bool ok = settingsSave();

    tft.fillScreen(UI_BG);
    tft.setTextColor(ok ? UI.ok : UI.warn, UI_BG);
    tft.setCursor(70, 8);
    tft.print(ok ? "Calibration Saved" : "Save FAILED");

    tft.setTextColor(UI_TEXT, UI_BG);
    tft.setCursor(70,28);
    tft.printf("X:[%u..%u] Y:[%u..%u]", xMin,xMax,yMin,yMax);

    delay(1200);
    feature_exit_requested = true;
    return;
  }

  int16_t rx = 0, ry = 0;
  if (readTouchRawXY(rx, ry)) {
    xs[stepIdx] = (uint16_t)rx;
    ys[stepIdx] = (uint16_t)ry;
    stepIdx++;
    if (stepIdx<4) drawTarget(pts[stepIdx][0], pts[stepIdx][1]);
  }
  delay(100);
}
}
