#pragma once
// config.h — merged from bleconfig.h, wificonfig.h, subconfig.h

/* ───────────── Common includes ───────────── */
#include <Arduino.h>
#include <TFT_eSPI.h>
#include <PCF8574.h>
#include <XPT2046_Touchscreen.h>
#include <SPI.h>
#include <Wire.h>
#include <EEPROM.h>
#include <Preferences.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <RCSwitch.h>
#include <SD.h>
#include <Update.h>
#include <ESPmDNS.h>
#include <nRF24L01.h>
#include <RF24.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_wifi_types.h>
#include <esp_system.h>
#include <esp_event.h>
#include <esp_event_loop.h>
#include <nvs_flash.h>

// Use NimBLE for all BLE functionality, via the BleCompat shim which
// exposes BLEDevice/BLEScan/etc as aliases to NimBLE types.
#include "BleCompat.h"

#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_gap_bt_api.h"

#include "arduinoFFT.h"
#include "ELECHOUSE_CC1101_SRC_DRV.h"
#include "utils.h"
#include "shared.h"

// NOTE: removed `using namespace std;` here. On newer Arduino-ESP32 cores
// (3.x / newer GCC+libstdc++), <cstddef> brings std::byte into scope, and
// combined with this blanket using-directive every unqualified `byte`
// (Arduino's own uint8_t alias) became ambiguous between ::byte and
// std::byte across every file that includes this header — that's the
// actual cause of the "reference to 'byte' is ambiguous" errors, not a
// NimBLE/Core mismatch. Nothing in this codebase actually relied on the
// blanket import (checked: no unqualified string/vector/map/sort/etc. —
// everything already uses the std:: prefix), so just removing it is safe.

/* ───────────── Common externs ───────────── */
extern TFT_eSPI tft;
extern PCF8574 pcf;

/* ───────────── BLE namespaces ───────────── */
namespace BleJammer {
  void blejamSetup();
  void blejamLoop();
  void exit();
}
namespace BleSpoofer {
  void spooferSetup();
  void spooferLoop();
  void exit();
}
namespace SourApple {
  void sourappleSetup();
  void sourappleLoop();
  void exit();
}
namespace AirTagSpoofer {
  void airTagSetup();
  void airTagLoop();
  void exit();
}
namespace AirTagSniffer {
  void airTagSnifferSetup();
  void airTagSnifferLoop();
  void exit();
}
namespace BleSkimmer {
  void bleSkimmerSetup();
  void bleSkimmerLoop();
  void exit();
}
/** Init NimBLE once (releases unused Classic BT RAM first). Safe to call repeatedly. */
bool ensureBleStackReady();

namespace BleScan {
  void bleScanSetup();
  void bleScanLoop();
  void exit();
  // Background BLE scanner: runs periodically in its own task, caching results.
  void startBackgroundScanner();
  // Last known BLE device count from background/foreground scans.
  int  getLastCount();
}

/** One-shot NimBLE bring-up (releases Classic BT RAM first). Safe to call repeatedly. */
bool ensureBleStackReady();
namespace Scanner {
  void scannerSetup();
  void scannerLoop();
  void exit();
}
namespace ProtoKill {
  void prokillSetup();
  void prokillLoop();
  void exit();
}
namespace EsbSniffer {
  void esbSnifferSetup();
  void esbSnifferLoop();
  void exit();
}
namespace EsbReplay {
  void esbReplaySetup();
  void esbReplayLoop();
  void exit();
}
namespace MouseJack {
  void mouseJackSetup();
  void mouseJackLoop();
  void exit();
}
namespace MouseJackInject {
  void mouseJackInjectSetup();
  void mouseJackInjectLoop();
  void exit();
}
namespace BleSniffer {
  void blesnifferSetup();
  void blesnifferLoop();
  void exit();
}

/* ───────────── SubGHz namespaces ───────────── */
namespace replayat {
  void ReplayAttackSetup();
  void ReplayAttackLoop();
}
namespace SavedProfile {
  void saveSetup();
  void saveLoop();
}
namespace subjammer {
  void subjammerSetup();
  void subjammerLoop();
}
namespace SubBrute {
  void subBruteSetup();
  void subBruteLoop();
}
namespace jammingdetector {
  void Setup();
  void Loop();
}

/* ───────────── WiFi namespaces ───────────── */
namespace PacketMonitor {
  void ptmSetup();
  void ptmLoop();
}
namespace BeaconSpammer {
  void beaconSpamSetup();
  void beaconSpamLoop();
}
namespace DeauthDetect {
  void deauthdetectSetup();
  void deauthdetectLoop();
}
namespace WifiScan {
  void wifiscanSetup();
  void wifiscanLoop();
  // Background WiFi scanner: runs when no feature is active, caching results.
  void startBackgroundScanner();
  // Last known WiFi network count from background/foreground scans.
  int  getLastCount();
  bool wifiCacheValidForReuse();
  int  staWifiScanSync();
  bool loadApListFromWifiCache(wifi_ap_record_t** ap_list, int* network_count,
                               int (*compare_ap)(const void*, const void*));
}
namespace CaptivePortal {
  void cportalSetup();
  void cportalLoop();
}
namespace Deauther {
  void deautherSetup();
  void deautherLoop();
}
namespace ProbeRequestFlood {
  void probeRequestFloodSetup();
  void probeRequestFloodLoop();
}
namespace HiddenSsidReveal {
  void hiddenSsidSetup();
  void hiddenSsidLoop();
}
namespace WpsScanner {
  void wpsScannerSetup();
  void wpsScannerLoop();
}
namespace ArpScanner {
  void arpScannerSetup();
  void arpScannerLoop();
}
namespace KarmaAttack {
  void karmaSetup();
  void karmaLoop();
}
namespace FirmwareUpdate {
  void updateSetup();
  void updateLoop();
}
